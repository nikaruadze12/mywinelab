# WineLab - UniPay ინტეგრაციის გზამკვლევი

## 📋 სარჩევი

1. [მიმოხილვა](#მიმოხილვა)
2. [ინსტალაცია](#ინსტალაცია)
3. [კონფიგურაცია](#კონფიგურაცია)
4. [API Endpoints](#api-endpoints)
5. [სატესტო რეჟიმი](#სატესტო-რეჟიმი)
6. [პროდაქშენზე გადასვლა](#პროდაქშენზე-გადასვლა)
7. [Webhook-ების დაყენება](#webhook-ების-დაყენება)
8. [პრობლემების აღმოფხვრა](#პრობლემების-აღმოფხვრა)

---

## მიმოხილვა

WineLab იყენებს UniPay-ს ონლაინ გადახდების მისაღებად. მხარდაჭერილია:
- 💳 Visa / MasterCard / AMEX ბარათები
- 📱 Google Pay
- 🍎 Apple Pay
- 💰 UniPay საფულე

## ინსტალაცია

დამოკიდებულება უკვე დაინსტალირებულია:
```bash
npm install node-fetch@2
```

## კონფიგურაცია

### .env ფაილი

```env
# UniPay Configuration
UNIPAY_MODE=sandbox   # sandbox ან production

# Sandbox credentials (სატესტო)
UNIPAY_SANDBOX_MERCHANT_ID=your_sandbox_merchant_id
UNIPAY_SANDBOX_SECRET_KEY=your_sandbox_secret_key

# Production credentials (რეალური)
UNIPAY_MERCHANT_ID=your_production_merchant_id
UNIPAY_SECRET_KEY=your_production_secret_key
```

### UniPay ბიზნეს ანგარიშის შექმნა

1. გადადი https://business.unipay.com
2. დაარეგისტრირე ბიზნეს ანგარიში
3. გაიარე ვერიფიკაცია
4. დაამატე პროექტი (Project)
5. მიიღე Merchant ID და Secret Key

## API Endpoints

### GET /api/unipay/config
კონფიგურაციის შემოწმება.

**Response:**
```json
{
  "enabled": true,
  "mode": "sandbox",
  "currency": "GEL",
  "merchantConfigured": true,
  "paymentMethods": ["card", "wallet", "googlepay", "applepay"]
}
```

### POST /api/unipay/create-payment
ახალი გადახდის შექმნა.

**Request:**
```json
{
  "orderId": "MISDGR73",
  "amount": 48,
  "description": "WineLab შეკვეთა #MISDGR73"
}
```

**Response (Sandbox):**
```json
{
  "success": true,
  "paymentId": "DEMO_1764909406458_166749c5",
  "checkoutUrl": "http://localhost:3000/payment-success.html?orderId=MISDGR73&demo=true",
  "mode": "sandbox",
  "message": "სატესტო რეჟიმი - გადახდა სიმულირებულია"
}
```

**Response (Production):**
```json
{
  "success": true,
  "paymentId": "UP_12345678",
  "checkoutUrl": "https://checkout.unipay.com/pay/UP_12345678",
  "mode": "production"
}
```

### GET /api/unipay/status/:orderId
გადახდის სტატუსის შემოწმება.

**Response:**
```json
{
  "orderId": "MISDGR73",
  "paymentStatus": "paid",
  "orderStatus": "confirmed",
  "totalAmount": 48,
  "unipayPaymentId": "UP_12345678",
  "paidAt": "2025-12-05T04:37:08.891Z"
}
```

### POST /api/unipay/callback
UniPay-დან Webhook callback (ავტომატური).

### POST /api/unipay/simulate-payment (მხოლოდ Sandbox)
გადახდის სიმულაცია ტესტირებისთვის.

**Request:**
```json
{
  "orderId": "MISDGR73",
  "success": true
}
```

## სატესტო რეჟიმი

Sandbox რეჟიმში:
1. გადახდა არ მიდის რეალურ ბანკში
2. მომხმარებელი გადამისამართდება success გვერდზე
3. გადახდა ავტომატურად სიმულირდება

**ტესტირება:**
1. გახსენი http://localhost:3000
2. დაამატე პროდუქტი კალათაში
3. გააკეთე შეკვეთა
4. დააჭირე "ბარათით გადახდა"
5. ნახავ success გვერდს "🧪 სატესტო რეჟიმი" badge-ით

## პროდაქშენზე გადასვლა

1. **UniPay Dashboard-ში:**
   - გაიარე ბიზნეს ვერიფიკაცია
   - მიიღე Production credentials
   - დააყენე Callback URL

2. **.env ფაილში:**
```env
UNIPAY_MODE=production
UNIPAY_MERCHANT_ID=your_real_merchant_id
UNIPAY_SECRET_KEY=your_real_secret_key
```

3. **გადატვირთე სერვერი:**
```bash
pm2 restart winelab
```

## Webhook-ების დაყენება

UniPay Dashboard-ში მიუთითე Callback URL:
```
https://yourdomain.com/api/unipay/callback
```

### Webhook Events:
- `Completed` / `Success` / `Paid` - გადახდა წარმატებული
- `Failed` / `Declined` - გადახდა უარყოფილი
- `Cancelled` - გადახდა გაუქმებული

### Signature Verification
Production-ში ყოველი callback ვერიფიცირდება HMAC-SHA256 ხელმოწერით.

## პრობლემების აღმოფხვრა

### "UniPay არ არის კონფიგურირებული"
➡️ შეამოწმე .env ფაილში UNIPAY_MERCHANT_ID და UNIPAY_SECRET_KEY

### "შეკვეთა ვერ მოიძებნა"
➡️ შეკვეთის ID არასწორია ან შეკვეთა წაშლილია

### "შეკვეთა უკვე გადახდილია"
➡️ ამ შეკვეთისთვის გადახდა უკვე მიღებულია

### Callback არ მოდის
➡️ შეამოწმე:
1. Callback URL მისაწვდომია ინტერნეტიდან
2. HTTPS სერტიფიკატი ვალიდურია
3. Firewall არ ბლოკავს

### სერვერის ლოგები
```bash
# ლოგების ნახვა
pm2 logs winelab

# რეალურ დროში
pm2 logs winelab --lines 100 -f
```

---

## 🔗 სასარგებლო ლინკები

- UniPay Business: https://business.unipay.com
- UniPay Docs: https://docs.unipay.com
- API Status: https://status.unipay.com

---

ბოლო განახლება: 2025-12-05
