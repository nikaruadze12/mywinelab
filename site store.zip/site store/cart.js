// ========== კალათის საერთო ლოგიკა ==========
let cart = [];

function initCart() {
    try {
        const saved = localStorage.getItem('wineCart');
        if (saved) cart = JSON.parse(saved);
    } catch { cart = []; }
    updateCartUI();
}

function saveCart() {
    localStorage.setItem('wineCart', JSON.stringify(cart));
}

// ხელმისაწვდომი მარაგის გამოთვლა (მარაგი - კალათაში არსებული)
function getAvailableStock(productId, totalStock) {
    const inCart = cart.find(item => item.id === productId);
    const cartQuantity = inCart ? inCart.quantity : 0;
    return totalStock - cartQuantity;
}

function addProductToCart(product) {
    const existing = cart.find(item => item.id === product.id);
    
    // მარაგის შემოწმება
    const currentInCart = existing ? existing.quantity : 0;
    if (product.stock !== undefined && currentInCart >= product.stock) {
        if (typeof showNotification === 'function') {
            showNotification(`მარაგშია მხოლოდ ${product.stock} ერთეული`, 'warning');
        }
        return false;
    }
    
    if (existing) {
        existing.quantity++;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            cellarId: product.cellarId,
            cellarName: product.cellarName,
            category: product.category || 'wine',
            stock: product.stock, // მარაგის შენახვა
            quantity: 1
        });
    }
    saveCart();
    updateCartUI();
    return true;
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    saveCart();
    updateCartUI();
    // განაახლე პროდუქტების მარაგის ჩვენება თუ ფუნქცია არსებობს
    if (typeof renderProducts === 'function') renderProducts();
}

function updateQuantity(id, delta) {
    const item = cart.find(i => i.id === id);
    if (item) {
        const newQuantity = item.quantity + delta;
        
        // მარაგის შემოწმება გაზრდისას
        if (delta > 0 && item.stock !== undefined && newQuantity > item.stock) {
            if (typeof showNotification === 'function') {
                showNotification(`მარაგშია მხოლოდ ${item.stock} ერთეული`, 'warning');
            }
            return;
        }
        
        item.quantity = newQuantity;
        if (item.quantity <= 0) {
            removeFromCart(id);
        } else {
            saveCart();
            updateCartUI();
            // განაახლე პროდუქტების მარაგის ჩვენება
            if (typeof renderProducts === 'function') renderProducts();
        }
    }
}

function updateCartUI() {
    const countEl = document.getElementById('cartCount');
    const itemsEl = document.getElementById('cartItems');
    const totalEl = document.getElementById('cartTotal');
    const checkoutBtn = document.getElementById('checkoutBtn');
    
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    if (countEl) countEl.textContent = totalItems;
    if (totalEl) totalEl.textContent = totalPrice.toFixed(2) + '₾';
    if (checkoutBtn) checkoutBtn.disabled = cart.length === 0;
    
    if (itemsEl) {
        if (cart.length === 0) {
            itemsEl.innerHTML = '<div class="empty-cart">კალათა ცარიელია</div>';
        } else {
            itemsEl.innerHTML = cart.map(item => `
                <div class="cart-item">
                    <div class="cart-item-info">
                        <div class="cart-item-name">${item.name}</div>
                        <div class="cart-item-cellar">${item.cellarName}</div>
                        <div class="cart-item-price">${item.price}₾</div>
                    </div>
                    <div class="cart-item-actions">
                        <button onclick="updateQuantity(${item.id}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button onclick="updateQuantity(${item.id}, 1)">+</button>
                        <button onclick="removeFromCart(${item.id})" class="remove-btn">×</button>
                    </div>
                </div>
            `).join('');
        }
    }
}

function toggleCart() {
    const sidebar = document.getElementById('cartSidebar');
    const overlay = document.getElementById('cartOverlay');
    if (sidebar && overlay) {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('open');
    }
}

function openCheckout() {
    if (cart.length === 0) return;
    toggleCart();
    document.getElementById('checkoutModal').style.display = 'flex';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
}

async function submitOrder(event) {
    event.preventDefault();
    
    const btn = event.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'იგზავნება...';
    
    const customer = {
        name: document.getElementById('customerName').value.trim(),
        phone: document.getElementById('customerPhone').value.trim(),
        email: document.getElementById('customerEmail')?.value.trim() || '',
        address: document.getElementById('customerAddress').value.trim(),
        comment: document.getElementById('customerComment')?.value.trim() || ''
    };
    
    try {
        const response = await apiCall('/orders', {
            method: 'POST',
            body: JSON.stringify({ customer, items: cart })
        });
        
        cart = [];
        saveCart();
        updateCartUI();
        closeModal('checkoutModal');
        event.target.reset();
        
        // გადამისამართება გადახდის გვერდზე
        window.location.href = `payment.html?orderId=${response.orderId}`;
    } catch (error) {
        showNotification(error.message || 'შეცდომა', 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = 'გაგზავნა';
    }
}
