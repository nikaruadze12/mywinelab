// Default data is empty - all data will be stored in files
// These are fallback variables only for frontend if API fails
const cellars = [];
const products = [];