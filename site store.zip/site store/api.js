// ========== API კონფიგურაცია ==========
const API_BASE_URL = '/api';

// ========== უსაფრთხოების ფუნქციები ==========
function sanitizeInput(str) {
    if (!str) return '';
    return String(str)
        .trim()
        .replace(/[<>]/g, '')
        .replace(/javascript:/gi, '')
        .replace(/on\w+=/gi, '');
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========== API Helper with JWT ==========
// მხარდაჭერა ორი ფორმატისთვის:
// 1. apiCall(endpoint, options) - options ობიექტი
// 2. apiCall(endpoint, method, body) - ცალკე method და body
async function apiCall(endpoint, methodOrOptions = {}, bodyData = null) {
    try {
        const url = `${API_BASE_URL}${endpoint}`;
        const token = typeof getAccessToken === 'function' ? getAccessToken() : localStorage.getItem('accessToken');
        
        let config;
        
        // შევამოწმოთ რომელი ფორმატით გამოიძახეს
        if (typeof methodOrOptions === 'string') {
            // ფორმატი: apiCall(endpoint, method, body)
            config = {
                method: methodOrOptions,
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            };
            if (bodyData) {
                config.body = JSON.stringify(bodyData);
            }
        } else {
            // ფორმატი: apiCall(endpoint, options)
            config = {
                headers: {
                    'Content-Type': 'application/json',
                    ...methodOrOptions.headers
                },
                credentials: 'include',
                ...methodOrOptions
            };
        }
        
        // Add JWT token if available
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        
        let response = await fetch(url, config);
        
        // Token expired - try refresh
        if (response.status === 401) {
            const data = await response.json().catch(() => ({}));
            if (data.code === 'TOKEN_EXPIRED' && typeof refreshAccessToken === 'function') {
                const newToken = await refreshAccessToken();
                if (newToken) {
                    config.headers['Authorization'] = `Bearer ${newToken}`;
                    response = await fetch(url, config);
                }
            }
        }
        
        // Rate limit handling
        if (response.status === 429) {
            const data = await response.json().catch(() => ({}));
            const retryAfter = data.retryAfter || 60;
            throw new Error(`ძალიან ბევრი მოთხოვნა. მოიცადეთ ${retryAfter} წამი.`);
        }
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `შეცდომა: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API შეცდომა:', error);
        throw error;
    }
}

// ========== ნოტიფიკაციები ==========
let notificationQueue = [];
let isShowingNotification = false;

function showNotification(message, type = 'info') {
    // Queue system to prevent overlapping notifications
    notificationQueue.push({ message, type });
    if (!isShowingNotification) {
        processNotificationQueue();
    }
}

function processNotificationQueue() {
    if (notificationQueue.length === 0) {
        isShowingNotification = false;
        return;
    }
    
    isShowingNotification = true;
    const { message, type } = notificationQueue.shift();
    
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    const colors = {
        success: '#4CAF50',
        error: '#f44336',
        warning: '#ff9800',
        info: '#2196F3'
    };
    
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 1rem 2rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 3000;
        animation: slideIn 0.3s ease;
        background: ${colors[type] || colors.info};
        color: white;
        font-weight: 500;
        max-width: 400px;
        word-wrap: break-word;
    `;
    
    // Close button
    const closeBtn = document.createElement('span');
    closeBtn.textContent = '×';
    closeBtn.style.cssText = `
        margin-left: 15px;
        cursor: pointer;
        font-size: 1.2em;
        float: right;
    `;
    closeBtn.onclick = () => {
        notification.remove();
        processNotificationQueue();
    };
    notification.appendChild(closeBtn);
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
            processNotificationQueue();
        }, 300);
    }, 3000);
}

// ========== ფორმის ვალიდაცია ==========
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    // ქართული ფორმატი
    const cleaned = phone.replace(/\D/g, '');
    return cleaned.length >= 9 && cleaned.length <= 15;
}

function validatePrice(price) {
    const p = parseFloat(price);
    return !isNaN(p) && p >= 0 && p <= 100000;
}

// ========== Loading State ==========
function setButtonLoading(button, loading, originalText = null) {
    if (loading) {
        button.dataset.originalText = button.textContent;
        button.textContent = 'იტვირთება...';
        button.disabled = true;
    } else {
        button.textContent = originalText || button.dataset.originalText || 'შენახვა';
        button.disabled = false;
    }
}

// ========== CSS ანიმაციების დამატება ==========
if (!document.getElementById('notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}
