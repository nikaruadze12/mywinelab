/**
 * Let's Encrypt სერტიფიკატის გენერაცია Production-ისთვის
 * 
 * გაშვება: node setup-ssl.js --domain yourdomain.com --email admin@yourdomain.com
 * 
 * მოთხოვნები:
 * 1. დომენი უნდა მიუთითებდეს ამ სერვერზე
 * 2. პორტი 80 უნდა იყოს ღია (Let's Encrypt verification)
 * 3. სერვერი უნდა იყოს ინტერნეტიდან წვდომადი
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const domainIndex = args.indexOf('--domain');
const emailIndex = args.indexOf('--email');

if (domainIndex === -1 || emailIndex === -1) {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║     Let's Encrypt SSL სერტიფიკატის გენერატორი              ║
╠════════════════════════════════════════════════════════════╣
║                                                             ║
║  გამოყენება:                                                ║
║  node setup-ssl.js --domain example.com --email you@email   ║
║                                                             ║
║  ნაბიჯები:                                                  ║
║  1. დააინსტალირეთ Certbot: https://certbot.eff.org         ║
║  2. გაუშვით ეს სკრიპტი                                     ║
║  3. სერტიფიკატი ავტომატურად მოთავსდება ssl/ ფოლდერში      ║
║                                                             ║
║  Development-ისთვის:                                        ║
║  უკვე გაქვთ self-signed სერტიფიკატი ssl/ ფოლდერში         ║
║                                                             ║
╚════════════════════════════════════════════════════════════╝
    `);
    process.exit(1);
}

const domain = args[domainIndex + 1];
const email = args[emailIndex + 1];

console.log(`\n🔐 Let's Encrypt SSL Setup`);
console.log(`   Domain: ${domain}`);
console.log(`   Email: ${email}\n`);

const sslDir = path.join(__dirname, 'ssl');

// შევქმნათ ssl ფოლდერი თუ არ არსებობს
if (!fs.existsSync(sslDir)) {
    fs.mkdirSync(sslDir, { recursive: true });
}

// Production-ის ინსტრუქციები
console.log(`
═════════════════════════════════════════════════════════════
📋 Production SSL Setup Instructions:
═════════════════════════════════════════════════════════════

1. Install Certbot (Ubuntu/Debian):
   sudo apt update
   sudo apt install certbot

2. Stop the Node.js server (port 80 must be free)

3. Get certificate:
   sudo certbot certonly --standalone -d ${domain} --email ${email} --agree-tos

4. Copy certificates to ssl folder:
   sudo cp /etc/letsencrypt/live/${domain}/privkey.pem ssl/key.pem
   sudo cp /etc/letsencrypt/live/${domain}/fullchain.pem ssl/cert.pem
   sudo chown $USER:$USER ssl/*.pem

5. Update .env:
   LETSENCRYPT_DOMAIN=${domain}

6. Start server:
   npm start

7. Auto-renewal (add to crontab):
   0 0 1 * * certbot renew --quiet && cp /etc/letsencrypt/live/${domain}/*.pem /path/to/ssl/

═════════════════════════════════════════════════════════════
`);

// შევქმნათ renewal script
const renewScript = `#!/bin/bash
# Auto-renewal script for Let's Encrypt
certbot renew --quiet
cp /etc/letsencrypt/live/${domain}/privkey.pem ${sslDir}/key.pem
cp /etc/letsencrypt/live/${domain}/fullchain.pem ${sslDir}/cert.pem
systemctl restart winelab  # or: pm2 restart winelab
`;

fs.writeFileSync(path.join(sslDir, 'renew-ssl.sh'), renewScript);
console.log('✅ Created ssl/renew-ssl.sh for auto-renewal\n');
