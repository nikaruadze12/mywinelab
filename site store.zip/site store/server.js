require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');
const multer = require('multer');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const bcrypt = require('bcrypt');
const Redis = require('ioredis');
const database = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;
const HTTPS_PORT = process.env.HTTPS_PORT || 3443;
const BCRYPT_ROUNDS = 12;

// ========== Redis კონფიგურაცია ==========
let redis = null;
let useRedis = false;

async function initRedis() {
    if (process.env.REDIS_URL) {
        try {
            redis = new Redis(process.env.REDIS_URL, {
                maxRetriesPerRequest: 3,
                retryDelayOnFailover: 100,
                enableReadyCheck: true,
                connectTimeout: 5000
            });
            await redis.ping();
            useRedis = true;
            console.log('✅ Redis დაკავშირებულია');
        } catch (error) {
            console.warn('⚠️  Redis ვერ დაუკავშირდა, გამოიყენება მეხსიერება:', error.message);
            useRedis = false;
        }
    } else {
        console.warn('⚠️  REDIS_URL არ არის .env-ში, გამოიყენება მეხსიერება (development mode)');
    }
}

// Refresh tokens - Redis ან Memory fallback
const memoryTokens = new Map();
const TOKEN_CLEANUP_INTERVAL = 60 * 60 * 1000; // 1 საათი

// ავტომატური token cleanup
setInterval(() => {
    if (!useRedis) {
        const now = Date.now();
        const expiredTime = 7 * 24 * 60 * 60 * 1000; // 7 დღე
        for (const [token, data] of memoryTokens.entries()) {
            if (now - data.createdAt > expiredTime) {
                memoryTokens.delete(token);
            }
        }
    }
}, TOKEN_CLEANUP_INTERVAL);

async function saveRefreshToken(token, userId) {
    const data = JSON.stringify({ userId, createdAt: Date.now() });
    if (useRedis) {
        await redis.setex(`refresh:${token}`, 7 * 24 * 60 * 60, data);
    } else {
        memoryTokens.set(token, JSON.parse(data));
    }
}

async function getRefreshToken(token) {
    if (useRedis) {
        const data = await redis.get(`refresh:${token}`);
        return data ? JSON.parse(data) : null;
    }
    return memoryTokens.get(token) || null;
}

async function deleteRefreshToken(token) {
    if (useRedis) {
        await redis.del(`refresh:${token}`);
    } else {
        memoryTokens.delete(token);
    }
}

// ========== JWT კონფიგურაცია ==========
const JWT_SECRET = process.env.JWT_SECRET || (() => {
    const secret = crypto.randomBytes(64).toString('hex');
    console.warn('⚠️  JWT_SECRET არ არის .env ფაილში! გენერირებულია დროებითი.');
    return secret;
})();

const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || crypto.randomBytes(64).toString('hex');
const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '7d';

function generateAccessToken(user) {
    return jwt.sign(
        { 
            id: user.id, 
            username: user.username, 
            role: user.role, 
            cellarId: user.cellarId,
            iat: Math.floor(Date.now() / 1000)
        },
        JWT_SECRET,
        { expiresIn: ACCESS_TOKEN_EXPIRY }
    );
}

async function generateRefreshToken(user) {
    const token = jwt.sign(
        { id: user.id, username: user.username },
        JWT_REFRESH_SECRET,
        { expiresIn: REFRESH_TOKEN_EXPIRY }
    );
    await saveRefreshToken(token, user.id);
    return token;
}

// ========== Bcrypt პაროლის ფუნქციები ==========
async function hashPasswordBcrypt(password) {
    return await bcrypt.hash(password, BCRYPT_ROUNDS);
}

async function verifyPasswordBcrypt(password, hash) {
    return await bcrypt.compare(password, hash);
}

// Legacy SHA256 (ძველი პაროლებისთვის - მიგრაციისთვის)
function verifyPasswordLegacy(password, storedHash, salt) {
    const effectiveSalt = salt || '';
    const hash = crypto.createHash('sha256').update(password + effectiveSalt).digest('hex');
    return hash === storedHash;
}

// Smart password verification + auto-migration to bcrypt
async function verifyPassword(password, storedHash, salt, userId = null) {
    // Bcrypt hash იწყება $2
    if (storedHash.startsWith('$2')) {
        return await verifyPasswordBcrypt(password, storedHash);
    }
    
    // Legacy SHA256
    const isValid = verifyPasswordLegacy(password, storedHash, salt);
    
    // Auto-migrate to bcrypt if valid
    if (isValid && userId) {
        try {
            const newHash = await hashPasswordBcrypt(password);
            database.users.updatePassword(userId, newHash, '');
            console.log(`✅ პაროლი მიგრირებულია bcrypt-ზე: user ${userId}`);
        } catch (e) {
            console.error('პაროლის მიგრაციის შეცდომა:', e);
        }
    }
    
    return isValid;
}

// ========== მეილის კონფიგურაცია ==========
const WINELAB_EMAIL = process.env.EMAIL_USER || 'mywinelab@gmail.com';
const EMAIL_CONFIG = {
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER || 'mywinelab@gmail.com',
        pass: process.env.EMAIL_PASS || ''
    }
};

if (!process.env.EMAIL_PASS) {
    console.warn('⚠️  EMAIL_PASS არ არის .env ფაილში! მეილები არ გაიგზავნება.');
}

const transporter = nodemailer.createTransport(EMAIL_CONFIG);

// Test mode - მეილების გამორთვა ტესტირების დროს
const isTestMode = process.env.TEST_MODE === 'true' || process.env.TEST_MODE === '1';

if (isTestMode) {
    console.log('🧪 TEST MODE: მეილები გამორთულია');
}

async function sendEmail(to, subject, htmlContent) {
    // Test mode - არ გაგზავნოს მეილი
    if (isTestMode) {
        console.log(`📧 [TEST] მეილი გამოტოვებულია: ${to} - ${subject.substring(0, 50)}...`);
        return { success: true, messageId: 'test-mode', skipped: true };
    }
    
    if (!process.env.EMAIL_PASS) {
        console.log(`📧 [DEV] მეილი (არ გაიგზავნა): ${to} - ${subject}`);
        return { success: true, messageId: 'dev-mode' };
    }
    
    try {
        const info = await transporter.sendMail({
            from: `"WineLab Georgia" <${WINELAB_EMAIL}>`,
            to: to,
            subject: subject,
            html: htmlContent
        });
        console.log(`✅ მეილი გაიგზავნა: ${to}`);
        return { success: true, messageId: info.messageId };
    } catch (error) {
        console.error(`❌ მეილის გაგზავნის შეცდომა (${to}):`, error.message);
        return { success: false, error: error.message };
    }
}

// მარაგის გაფრთხილების მეილი
async function sendLowStockAlert(product, cellarOwnerEmail) {
    const subject = `⚠️ მარაგი იწურება: ${product.name}`;
    const htmlContent = `
        <div style="font-family: 'Noto Sans Georgian', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a1a; color: #fff; border-radius: 12px; overflow: hidden;">
            <div style="background: linear-gradient(135deg, #8B2635 0%, #6d1f2a 100%); padding: 30px; text-align: center;">
                <h1 style="margin: 0; color: #C9A962;">⚠️ მარაგის გაფრთხილება</h1>
            </div>
            <div style="padding: 30px;">
                <p style="color: #ccc; font-size: 16px;">გამარჯობა,</p>
                <p style="color: #ccc; font-size: 16px;">გაცნობებთ, რომ თქვენი პროდუქტის მარაგი კრიტიკულად დაბალია:</p>
                
                <div style="background: #2a2a2a; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #ff9800;">
                    <h3 style="color: #C9A962; margin: 0 0 10px 0;">${escapeHtml(product.name)}</h3>
                    <p style="color: #ff9800; font-size: 24px; margin: 10px 0; font-weight: bold;">
                        📦 დარჩენილი მარაგი: ${product.stock} ერთეული
                    </p>
                    <p style="color: #999; margin: 0;">კატეგორია: ${product.category === 'wine' ? 'ღვინო' : product.category === 'spirit' ? 'მაღალალკოჰოლიანი' : 'ყურძნისეული'}</p>
                </div>
                
                <p style="color: #ccc; font-size: 16px;">გთხოვთ შეავსოთ მარაგი რაც შეიძლება სწრაფად.</p>
            </div>
            <div style="background: #111; padding: 20px; text-align: center; color: #666; font-size: 12px;">
                <p style="margin: 0;">© ${new Date().getFullYear()} WineLab Georgia</p>
            </div>
        </div>
    `;
    
    return await sendEmail(cellarOwnerEmail, subject, htmlContent);
}

// შევამოწმოთ და გავაგზავნოთ low stock alert
async function checkAndSendLowStockAlert(productId) {
    if (!database.products.needsLowStockAlert(productId)) {
        return null;
    }
    
    const product = database.products.getById(productId);
    if (!product) return null;
    
    const cellarOwner = database.users.getAll().find(u => u.cellarId === product.cellarId && u.role === 'cellar_admin');
    if (!cellarOwner || !cellarOwner.email) {
        console.log(`⚠️ მარნის მფლობელი ვერ მოიძებნა cellarId: ${product.cellarId}`);
        return null;
    }
    
    const result = await sendLowStockAlert(product, cellarOwner.email);
    
    if (result.success) {
        database.products.markLowStockAlertSent(productId);
        console.log(`📧 Low stock alert გაიგზავნა: ${product.name} -> ${cellarOwner.email}`);
    }
    
    return result;
}

// ========== უსაფრთხოების კონფიგურაცია ==========
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ALLOWED_FILE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const DATA_DIR = path.join(__dirname, 'data');

// Rate limiting - გაუმჯობესებული
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW = 60000; // 1 წუთი
const RATE_LIMIT_MAX = 200; // 200 მოთხოვნა წუთში (შემცირებული)
const RATE_LIMIT_AUTH_MAX = 10; // 10 login მცდელობა წუთში

// Rate limit cleanup
setInterval(() => {
    const now = Date.now();
    for (const [key, record] of rateLimitMap.entries()) {
        if (now - record.startTime > RATE_LIMIT_WINDOW * 2) {
            rateLimitMap.delete(key);
        }
    }
}, RATE_LIMIT_WINDOW);

function rateLimiter(req, res, next) {
    const ip = req.ip || req.connection.remoteAddress || 'unknown';
    const now = Date.now();
    const isAuthRoute = req.path.includes('/login') || req.path.includes('/refresh-token');
    const maxRequests = isAuthRoute ? RATE_LIMIT_AUTH_MAX : RATE_LIMIT_MAX;
    const key = isAuthRoute ? `auth:${ip}` : ip;
    
    if (!rateLimitMap.has(key)) {
        rateLimitMap.set(key, { count: 1, startTime: now });
        return next();
    }
    
    const record = rateLimitMap.get(key);
    
    if (now - record.startTime > RATE_LIMIT_WINDOW) {
        rateLimitMap.set(key, { count: 1, startTime: now });
        return next();
    }
    
    if (record.count >= maxRequests) {
        console.warn(`⚠️ Rate limit: ${ip} (${req.path})`);
        return res.status(429).json({ 
            error: 'ძალიან ბევრი მოთხოვნა. გთხოვთ მოიცადოთ.',
            retryAfter: Math.ceil((RATE_LIMIT_WINDOW - (now - record.startTime)) / 1000)
        });
    }
    
    record.count++;
    next();
}

// ========== უსაფრთხოების ფუნქციები ==========
function sanitizeString(str) {
    if (!str) return '';
    return String(str)
        .trim()
        .slice(0, 1000) // მაქსიმუმ 1000 სიმბოლო
        .replace(/[<>]/g, '')
        .replace(/javascript:/gi, '')
        .replace(/on\w+=/gi, '')
        .replace(/data:/gi, '')
        .replace(/vbscript:/gi, '')
        .replace(/\x00/g, ''); // null bytes
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}

function validatePrice(price) {
    const p = parseFloat(price);
    return !isNaN(p) && p >= 0 && p <= 100000;
}

function validateYear(year) {
    if (!year) return true;
    const y = parseInt(year);
    return !isNaN(y) && y >= 1800 && y <= new Date().getFullYear() + 1;
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePhone(phone) {
    // ქართული ტელეფონის ფორმატი
    const cleaned = phone.replace(/\D/g, '');
    return cleaned.length >= 9 && cleaned.length <= 15;
}

// ========== Middleware ==========
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"],
            imgSrc: ["'self'", "data:", "blob:"],
            scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
            scriptSrcAttr: ["'unsafe-inline'"],
            connectSrc: ["'self'"]
        }
    },
    crossOriginEmbedderPolicy: false
}));

app.use(cors({ 
    origin: true, 
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());
app.use(rateLimiter);

// Security headers
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
});

app.use(express.static(__dirname, {
    dotfiles: 'ignore',
    etag: true,
    setHeaders: (res, filePath) => {
        // JS და CSS ფაილებისთვის - no cache (development) ან short cache
        if (filePath.endsWith('.js') || filePath.endsWith('.css')) {
            res.setHeader('Cache-Control', 'no-cache, must-revalidate');
        } 
        // სურათებისთვის - longer cache
        else if (filePath.match(/\.(jpg|jpeg|png|gif|webp|svg)$/)) {
            res.setHeader('Cache-Control', 'public, max-age=86400'); // 1 დღე
        }
        // HTML - no cache
        else if (filePath.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-cache, must-revalidate');
        }
    }
}));

// ========== JWT Authentication Middleware ==========
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const tokenFromHeader = authHeader && authHeader.split(' ')[1];
    const tokenFromCookie = req.cookies?.accessToken;
    const token = tokenFromHeader || tokenFromCookie;
    
    if (!token) {
        return res.status(401).json({ error: 'ავტორიზაცია საჭიროა' });
    }
    
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            if (err.name === 'TokenExpiredError') {
                return res.status(401).json({ error: 'სესია ამოიწურა', code: 'TOKEN_EXPIRED' });
            }
            return res.status(403).json({ error: 'არასწორი token' });
        }
        
        // შევამოწმოთ რომ მომხმარებელი ჯერ კიდევ არსებობს
        const dbUser = database.users.getById(user.id);
        if (!dbUser) {
            return res.status(403).json({ error: 'მომხმარებელი ვერ მოიძებნა' });
        }
        
        req.user = user;
        next();
    });
}

function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'ავტორიზაცია საჭიროა' });
        }
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
        }
        next();
    };
}

// ========== ავტორიზაცია ==========
app.post('/api/login', async (req, res) => {
    try {
        let { username, password } = req.body;
        username = sanitizeString(username);
        
        if (!username || !password) {
            return res.status(400).json({ error: 'შეავსეთ ყველა ველი' });
        }
        
        if (username.length < 3 || username.length > 100) {
            return res.status(400).json({ error: 'არასწორი მომხმარებლის სახელი' });
        }
        
        const user = database.users.getByUsername(username);
        
        if (!user) {
            // Timing attack-ის თავიდან ასაცილებლად
            await bcrypt.hash('dummy', 10);
            return res.status(401).json({ error: 'არასწორი მონაცემები' });
        }
        
        const isValid = await verifyPassword(password, user.password, user.salt, user.id);
        if (!isValid) {
            return res.status(401).json({ error: 'არასწორი მონაცემები' });
        }
        
        const accessToken = generateAccessToken(user);
        const refreshToken = await generateRefreshToken(user);
        
        const isSecure = req.secure || req.headers['x-forwarded-proto'] === 'https';
        
        res.cookie('accessToken', accessToken, {
            httpOnly: true,
            secure: isSecure,
            sameSite: 'lax',
            maxAge: 15 * 60 * 1000
        });
        
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: isSecure,
            sameSite: 'lax',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });
        
        const { password: _, salt: __, ...safeUser } = user;
        console.log(`✅ ავტორიზაცია: ${user.username} (${user.role})`);
        
        res.json({
            user: safeUser,
            accessToken,
            expiresIn: 15 * 60
        });
    } catch (error) {
        console.error('ავტორიზაციის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.post('/api/refresh-token', async (req, res) => {
    try {
        const refreshToken = req.cookies?.refreshToken || req.body.refreshToken;
        
        if (!refreshToken) {
            return res.status(401).json({ error: 'Refresh token საჭიროა' });
        }
        
        const tokenData = await getRefreshToken(refreshToken);
        if (!tokenData) {
            return res.status(403).json({ error: 'არასწორი refresh token' });
        }
        
        jwt.verify(refreshToken, JWT_REFRESH_SECRET, async (err, decoded) => {
            if (err) {
                await deleteRefreshToken(refreshToken);
                return res.status(403).json({ error: 'Refresh token ამოიწურა' });
            }
            
            const user = database.users.getById(decoded.id);
            if (!user) {
                await deleteRefreshToken(refreshToken);
                return res.status(403).json({ error: 'მომხმარებელი ვერ მოიძებნა' });
            }
            
            const newAccessToken = generateAccessToken(user);
            const isSecure = req.secure || req.headers['x-forwarded-proto'] === 'https';
            
            res.cookie('accessToken', newAccessToken, {
                httpOnly: true,
                secure: isSecure,
                sameSite: 'lax',
                maxAge: 15 * 60 * 1000
            });
            
            res.json({ accessToken: newAccessToken, expiresIn: 15 * 60 });
        });
    } catch (error) {
        console.error('Token refresh შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.post('/api/logout', async (req, res) => {
    const refreshToken = req.cookies?.refreshToken;
    if (refreshToken) {
        await deleteRefreshToken(refreshToken);
    }
    
    res.clearCookie('accessToken');
    res.clearCookie('refreshToken');
    res.json({ message: 'გამოსვლა წარმატებულია' });
});

app.get('/api/auth/verify', authenticateToken, (req, res) => {
    const user = database.users.getById(req.user.id);
    if (!user) {
        return res.status(404).json({ error: 'მომხმარებელი ვერ მოიძებნა' });
    }
    const { password: _, salt: __, ...safeUser } = user;
    res.json({ user: safeUser });
});

// ========== USERS API ==========
app.get('/api/users', authenticateToken, requireRole('admin'), (req, res) => {
    try {
        const users = database.users.getAll();
        const safeUsers = users.map(({ password, salt, ...u }) => u);
        res.json(safeUsers);
    } catch (error) {
        console.error('მომხმარებლების ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.post('/api/users', authenticateToken, requireRole('admin'), async (req, res) => {
    try {
        let { username, email, password, role, cellarId } = req.body;
        
        username = sanitizeString(username);
        email = sanitizeString(email);
        role = sanitizeString(role);
        
        // ვალიდაცია
        if (!username || username.length < 3 || username.length > 50) {
            return res.status(400).json({ error: 'მომხმარებლის სახელი: 3-50 სიმბოლო' });
        }
        if (!email || !validateEmail(email)) {
            return res.status(400).json({ error: 'არასწორი ელ.ფოსტა' });
        }
        if (!password || password.length < 6 || password.length > 100) {
            return res.status(400).json({ error: 'პაროლი: 6-100 სიმბოლო' });
        }
        if (!['admin', 'cellar_admin', 'user'].includes(role)) {
            role = 'user';
        }
        
        const existingUser = database.users.getByUsername(username);
        if (existingUser) {
            return res.status(400).json({ error: 'მომხმარებელი ამ სახელით უკვე არსებობს' });
        }
        
        const existingEmail = database.users.getByEmail(email);
        if (existingEmail) {
            return res.status(400).json({ error: 'ეს ელ.ფოსტა უკვე გამოყენებულია' });
        }
        
        const hashedPassword = await hashPasswordBcrypt(password);
        const newUser = database.users.create({
            username,
            email,
            password: hashedPassword,
            salt: '',
            role,
            cellarId: cellarId ? parseInt(cellarId) : null,
            createdAt: new Date().toISOString()
        });
        
        const { password: _, salt: __, ...safeUser } = newUser;
        console.log(`✅ მომხმარებელი შეიქმნა: ${username} (${role})`);
        res.status(201).json(safeUser);
    } catch (error) {
        console.error('მომხმარებლის შექმნის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

// PUT /api/users/:id/password - პაროლის შეცვლა (მხოლოდ admin)
app.put('/api/users/:id/password', authenticateToken, requireRole('admin'), async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        const { password } = req.body;
        
        if (!password || password.length < 6 || password.length > 100) {
            return res.status(400).json({ error: 'პაროლი: 6-100 სიმბოლო' });
        }
        
        const user = database.users.getById(userId);
        if (!user) {
            return res.status(404).json({ error: 'მომხმარებელი ვერ მოიძებნა' });
        }
        
        const hashedPassword = await hashPasswordBcrypt(password);
        database.users.updatePassword(userId, hashedPassword, '');
        
        console.log(`✅ პაროლი შეიცვალა: ${user.username}`);
        res.json({ success: true, message: 'პაროლი შეიცვალა' });
    } catch (error) {
        console.error('პაროლის შეცვლის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

// ========== CELLARS API ==========

// ფუნქცია identificationCode-ის დასამალად არა-admin მომხმარებლებისთვის
function hideSensitiveCellarData(cellar, isAdmin) {
    if (!cellar) return null;
    if (isAdmin) return cellar;
    const { identificationCode, ...publicData } = cellar;
    return publicData;
}

app.get('/api/cellars', (req, res) => {
    try {
        let isAdmin = false;
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        
        if (token) {
            try {
                const user = jwt.verify(token, JWT_SECRET);
                isAdmin = user.role === 'admin';
            } catch (e) {}
        }
        
        if (req.query.all === 'true' && isAdmin) {
            // Admin ხედავს ყველა მარანს + identificationCode
            return res.json(database.cellars.getAll());
        }
        
        // სხვა მომხმარებლები ხედავენ მხოლოდ საჯარო მონაცემებს
        const cellars = database.cellars.getVisible();
        res.json(cellars.map(c => hideSensitiveCellarData(c, false)));
    } catch (error) {
        console.error('მარნების ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.get('/api/cellars/:id', (req, res) => {
    try {
        const cellarId = parseInt(req.params.id);
        if (isNaN(cellarId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const cellar = database.cellars.getById(cellarId);
        if (!cellar) {
            return res.status(404).json({ error: 'მარანი ვერ მოიძებნა' });
        }
        
        // შევამოწმოთ მომხმარებლის როლი
        let isAdmin = false;
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        
        if (token) {
            try {
                const user = jwt.verify(token, JWT_SECRET);
                isAdmin = user.role === 'admin';
                
                // დამალული მარანი - admin ან თავისი მარნის admin
                if (cellar.hidden && user.role !== 'admin' && user.cellarId !== cellarId) {
                    return res.status(404).json({ error: 'მარანი ვერ მოიძებნა' });
                }
            } catch {
                if (cellar.hidden) {
                    return res.status(404).json({ error: 'მარანი ვერ მოიძებნა' });
                }
            }
        } else if (cellar.hidden) {
            return res.status(404).json({ error: 'მარანი ვერ მოიძებნა' });
        }
        
        // identificationCode მხოლოდ admin-ს ეჩვენება
        res.json(hideSensitiveCellarData(cellar, isAdmin));
    } catch (error) {
        console.error('მარნის ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.post('/api/cellars', authenticateToken, requireRole('admin'), async (req, res) => {
    try {
        let { name, location, description, established, identificationCode, iban, bankName, accountHolder } = req.body;
        
        name = sanitizeString(name);
        location = sanitizeString(location);
        description = sanitizeString(description);
        identificationCode = sanitizeString(identificationCode);
        iban = sanitizeString(iban);
        bankName = sanitizeString(bankName);
        accountHolder = sanitizeString(accountHolder);
        
        if (!name || name.length < 2 || name.length > 100) {
            return res.status(400).json({ error: 'მარნის სახელი: 2-100 სიმბოლო' });
        }
        
        // საიდენტიფიკაციო კოდის ვალიდაცია (საქართველოში 9 ან 11 ციფრი)
        if (identificationCode && !/^\d{9}$|^\d{11}$/.test(identificationCode)) {
            return res.status(400).json({ error: 'საიდენტიფიკაციო კოდი უნდა იყოს 9 ან 11 ციფრი' });
        }
        
        const newCellar = database.cellars.create({
            name,
            location: location || null,
            description: description || null,
            established: established || new Date().getFullYear().toString(),
            identificationCode: identificationCode || null,
            iban: iban || null,
            bankName: bankName || null,
            accountHolder: accountHolder || null,
            createdAt: new Date().toISOString()
        });
        
        const cellarDir = path.join(DATA_DIR, 'cellars', `cellar_${newCellar.id}`);
        await fs.mkdir(path.join(cellarDir, 'products'), { recursive: true });
        await fs.mkdir(path.join(cellarDir, 'images'), { recursive: true });
        await fs.mkdir(path.join(cellarDir, 'info'), { recursive: true });
        
        console.log(`✅ მარანი შეიქმნა: ${name}`);
        res.status(201).json(newCellar);
    } catch (error) {
        console.error('მარნის შექმნის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.put('/api/cellars/:id', authenticateToken, (req, res) => {
    try {
        const cellarId = parseInt(req.params.id);
        if (isNaN(cellarId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const cellar = database.cellars.getById(cellarId);
        if (!cellar) {
            return res.status(404).json({ error: 'მარანი ვერ მოიძებნა' });
        }
        
        if (req.user.role !== 'admin' && req.user.cellarId !== cellarId) {
            return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
        }
        
        let { name, location, description, established, identificationCode, iban, bankName, accountHolder, hidden } = req.body;
        
        // identificationCode მხოლოდ admin-ს შეუძლია შეცვალოს
        if (identificationCode !== undefined && req.user.role !== 'admin') {
            return res.status(403).json({ error: 'საიდენტიფიკაციო კოდის შეცვლა მხოლოდ ადმინისტრატორს შეუძლია' });
        }
        
        // საიდენტიფიკაციო კოდის ვალიდაცია
        if (identificationCode && !/^\d{9}$|^\d{11}$/.test(identificationCode)) {
            return res.status(400).json({ error: 'საიდენტიფიკაციო კოდი უნდა იყოს 9 ან 11 ციფრი' });
        }
        
        database.cellars.update(cellarId, {
            name: name ? sanitizeString(name) : undefined,
            location: location !== undefined ? sanitizeString(location) : undefined,
            description: description !== undefined ? sanitizeString(description) : undefined,
            established: established ? sanitizeString(established) : undefined,
            identificationCode: identificationCode !== undefined ? sanitizeString(identificationCode) : undefined,
            iban: iban !== undefined ? sanitizeString(iban) : undefined,
            bankName: bankName !== undefined ? sanitizeString(bankName) : undefined,
            accountHolder: accountHolder !== undefined ? sanitizeString(accountHolder) : undefined,
            hidden: hidden !== undefined ? (hidden ? 1 : 0) : undefined
        });
        
        const updatedCellar = database.cellars.getById(cellarId);
        res.json(updatedCellar);
    } catch (error) {
        console.error('მარნის განახლების შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.put('/api/cellars/:id/visibility', authenticateToken, requireRole('admin'), (req, res) => {
    try {
        const cellarId = parseInt(req.params.id);
        if (isNaN(cellarId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        database.cellars.toggleVisibility(cellarId);
        invalidateProductsCache(); // Cache-ის განულება - მარნის ხილვადობა პროდუქტებზეც მოქმედებს
        const cellar = database.cellars.getById(cellarId);
        console.log(`✅ მარნის ხილვადობა შეიცვალა: ${cellar?.name} (${cellar?.hidden ? 'დამალული' : 'ხილული'})`);
        res.json(cellar);
    } catch (error) {
        console.error('ხილვადობის შეცვლის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.delete('/api/cellars/:id', authenticateToken, requireRole('admin'), async (req, res) => {
    try {
        const cellarId = parseInt(req.params.id);
        if (isNaN(cellarId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const cellar = database.cellars.getById(cellarId);
        if (!cellar) {
            return res.status(404).json({ error: 'მარანი ვერ მოიძებნა' });
        }
        
        database.deleteCellarWithData(cellarId);
        
        const cellarDir = path.join(DATA_DIR, 'cellars', `cellar_${cellarId}`);
        try {
            await fs.rm(cellarDir, { recursive: true, force: true });
        } catch (e) {}
        
        console.log(`✅ მარანი წაიშალა: ${cellar.name}`);
        res.json({ message: 'მარანი წაიშალა' });
    } catch (error) {
        console.error('მარნის წაშლის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

// ========== PRODUCTS API ==========

// პროდუქტების cache (5 წუთი)
let productsCache = { data: null, timestamp: 0, visibleCellarIds: null };
const CACHE_TTL = 5 * 60 * 1000; // 5 წუთი

function invalidateProductsCache() {
    productsCache = { data: null, timestamp: 0, visibleCellarIds: null };
}

function getVisibleProducts() {
    const now = Date.now();
    
    // cache ვალიდურია?
    if (productsCache.data && (now - productsCache.timestamp) < CACHE_TTL) {
        return productsCache.data;
    }
    
    // განახლება
    const products = database.products.getAll();
    const visibleCellars = database.cellars.getAll().filter(c => !c.hidden).map(c => c.id);
    const visibleProducts = products.filter(p => visibleCellars.includes(p.cellarId));
    
    productsCache = {
        data: visibleProducts,
        timestamp: now,
        visibleCellarIds: visibleCellars
    };
    
    return visibleProducts;
}

app.get('/api/products', (req, res) => {
    try {
        const { page, limit, category, cellarId, search } = req.query;
        
        let products = getVisibleProducts();
        
        // ფილტრაცია კატეგორიით
        if (category) {
            products = products.filter(p => p.category === category);
        }
        
        // ფილტრაცია მარნით
        if (cellarId) {
            const cId = parseInt(cellarId);
            products = products.filter(p => p.cellarId === cId);
        }
        
        // ძებნა
        if (search) {
            const searchLower = search.toLowerCase();
            products = products.filter(p => 
                p.name.toLowerCase().includes(searchLower) ||
                (p.description && p.description.toLowerCase().includes(searchLower))
            );
        }
        
        // Pagination
        if (page && limit) {
            const pageNum = parseInt(page) || 1;
            const limitNum = Math.min(parseInt(limit) || 20, 100); // მაქსიმუმ 100
            const offset = (pageNum - 1) * limitNum;
            
            const total = products.length;
            const paginatedProducts = products.slice(offset, offset + limitNum);
            
            return res.json({
                products: paginatedProducts,
                pagination: {
                    page: pageNum,
                    limit: limitNum,
                    total,
                    totalPages: Math.ceil(total / limitNum),
                    hasNext: offset + limitNum < total,
                    hasPrev: pageNum > 1
                }
            });
        }
        
        res.json(products);
    } catch (error) {
        console.error('პროდუქტების ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.get('/api/products/cellar/:cellarId', (req, res) => {
    try {
        const cellarId = parseInt(req.params.cellarId);
        if (isNaN(cellarId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const products = database.products.getByCellarId(cellarId);
        res.json(products);
    } catch (error) {
        console.error('პროდუქტების ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.get('/api/products/:id', (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        if (isNaN(productId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const product = database.products.getById(productId);
        if (!product) {
            return res.status(404).json({ error: 'პროდუქტი ვერ მოიძებნა' });
        }
        
        res.json(product);
    } catch (error) {
        console.error('პროდუქტის ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.post('/api/products', authenticateToken, requireRole('admin', 'cellar_admin'), (req, res) => {
    try {
        let { name, cellarId, category, color, sugar, spiritType, alcoholContent, 
              grapeProductType, price, year, stock, description } = req.body;
        
        name = sanitizeString(name);
        description = sanitizeString(description);
        cellarId = parseInt(cellarId);
        
        if (req.user.role === 'cellar_admin' && req.user.cellarId !== cellarId) {
            return res.status(403).json({ error: 'შეგიძლიათ მხოლოდ თქვენს მარანში დაამატოთ პროდუქტი' });
        }
        
        if (!name || name.length < 2 || name.length > 100) {
            return res.status(400).json({ error: 'პროდუქტის სახელი: 2-100 სიმბოლო' });
        }
        if (!validatePrice(price)) {
            return res.status(400).json({ error: 'არასწორი ფასი (0-100000)' });
        }
        if (!validateYear(year)) {
            return res.status(400).json({ error: 'არასწორი წელი' });
        }
        
        const cellar = database.cellars.getById(cellarId);
        if (!cellar) {
            return res.status(404).json({ error: 'მარანი ვერ მოიძებნა' });
        }
        
        const productCategory = ['wine', 'spirit', 'grape'].includes(category) ? category : 'wine';
        
        const newProduct = database.products.create({
            name,
            cellarId,
            cellarName: cellar.name,
            category: productCategory,
            type: productCategory === 'wine' ? `${color}_${sugar}` : null,
            color: productCategory === 'wine' ? sanitizeString(color) : null,
            sugar: productCategory === 'wine' ? sanitizeString(sugar) : null,
            spiritType: productCategory === 'spirit' ? sanitizeString(spiritType) : null,
            alcoholContent: productCategory === 'spirit' ? parseFloat(alcoholContent) || 40 : null,
            grapeProductType: productCategory === 'grape' ? sanitizeString(grapeProductType) : null,
            price: parseFloat(price),
            year: year ? parseInt(year) : null,
            stock: parseInt(stock) || 0,
            description: description || null,
            image: null,
            createdAt: new Date().toISOString()
        });
        
        console.log(`✅ პროდუქტი შეიქმნა: ${name} (${cellar.name})`);
        invalidateProductsCache(); // Cache-ის განულება
        res.status(201).json(newProduct);
    } catch (error) {
        console.error('პროდუქტის შექმნის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.put('/api/products/:id', authenticateToken, requireRole('admin', 'cellar_admin'), (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        if (isNaN(productId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const product = database.products.getById(productId);
        if (!product) {
            return res.status(404).json({ error: 'პროდუქტი ვერ მოიძებნა' });
        }
        
        if (req.user.role === 'cellar_admin' && req.user.cellarId !== product.cellarId) {
            return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
        }
        
        const { name, type, color, sugar, price, year, stock, description, spiritType, alcoholContent, grapeProductType } = req.body;
        
        // აშენება update ობიექტის - მხოლოდ გაგზავნილი ველები
        const updates = {};
        
        if (name !== undefined) {
            const cleanName = sanitizeString(name);
            if (cleanName.length < 2) {
                return res.status(400).json({ error: 'პროდუქტის სახელი მინიმუმ 2 სიმბოლო' });
            }
            updates.name = cleanName;
        }
        
        if (price !== undefined) {
            if (!validatePrice(price)) {
                return res.status(400).json({ error: 'არასწორი ფასი' });
            }
            updates.price = parseFloat(price);
        }
        
        if (stock !== undefined) {
            const stockNum = parseInt(stock);
            if (isNaN(stockNum) || stockNum < 0) {
                return res.status(400).json({ error: 'არასწორი მარაგი' });
            }
            updates.stock = stockNum;
        }
        
        if (year !== undefined) updates.year = year ? parseInt(year) : null;
        if (description !== undefined) updates.description = sanitizeString(description) || '';
        if (color !== undefined) updates.color = sanitizeString(color);
        if (sugar !== undefined) updates.sugar = sanitizeString(sugar);
        if (type !== undefined) updates.type = sanitizeString(type);
        if (spiritType !== undefined) updates.spiritType = sanitizeString(spiritType);
        if (alcoholContent !== undefined) updates.alcoholContent = parseFloat(alcoholContent) || null;
        if (grapeProductType !== undefined) updates.grapeProductType = sanitizeString(grapeProductType);
        
        // თუ color/sugar შეიცვალა, type-ც განვაახლოთ
        if ((color !== undefined || sugar !== undefined) && !type) {
            updates.type = `${updates.color || product.color}_${updates.sugar || product.sugar}`;
        }
        
        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ error: 'განახლებისთვის მონაცემები არ არის' });
        }
        
        database.products.update(productId, updates);
        invalidateProductsCache(); // Cache-ის განულება
        
        const updatedProduct = database.products.getById(productId);
        res.json(updatedProduct);
    } catch (error) {
        console.error('პროდუქტის განახლების შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.delete('/api/products/:id', authenticateToken, requireRole('admin', 'cellar_admin'), async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        if (isNaN(productId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const product = database.products.getById(productId);
        if (!product) {
            return res.status(404).json({ error: 'პროდუქტი ვერ მოიძებნა' });
        }
        
        if (req.user.role === 'cellar_admin' && req.user.cellarId !== product.cellarId) {
            return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
        }
        
        if (product.image) {
            try {
                const imagePath = path.join(__dirname, product.image);
                await fs.unlink(imagePath);
            } catch (e) {}
        }
        
        database.products.delete(productId);
        invalidateProductsCache(); // Cache-ის განულება
        console.log(`✅ პროდუქტი წაიშალა: ${product.name}`);
        res.json({ message: 'პროდუქტი წაიშალა' });
    } catch (error) {
        console.error('პროდუქტის წაშლის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

// ========== FILE UPLOAD ==========
const tempUploadDir = path.join(DATA_DIR, 'temp_uploads');

// Magic bytes ფაილის ტიპის ვერიფიკაციისთვის
const FILE_SIGNATURES = {
    'image/jpeg': [
        [0xFF, 0xD8, 0xFF, 0xE0],
        [0xFF, 0xD8, 0xFF, 0xE1],
        [0xFF, 0xD8, 0xFF, 0xE2],
        [0xFF, 0xD8, 0xFF, 0xE3],
        [0xFF, 0xD8, 0xFF, 0xE8]
    ],
    'image/png': [[0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]],
    'image/gif': [[0x47, 0x49, 0x46, 0x38, 0x37, 0x61], [0x47, 0x49, 0x46, 0x38, 0x39, 0x61]],
    'image/webp': [[0x52, 0x49, 0x46, 0x46]] // RIFF header
};

// Magic bytes შემოწმება
async function verifyFileSignature(filePath, declaredMimeType) {
    try {
        const fsSync = require('fs');
        const buffer = Buffer.alloc(12);
        const fd = fsSync.openSync(filePath, 'r');
        fsSync.readSync(fd, buffer, 0, 12, 0);
        fsSync.closeSync(fd);
        
        const signatures = FILE_SIGNATURES[declaredMimeType];
        if (!signatures) return false;
        
        for (const sig of signatures) {
            let match = true;
            for (let i = 0; i < sig.length; i++) {
                if (buffer[i] !== sig[i]) {
                    match = false;
                    break;
                }
            }
            if (match) return true;
        }
        return false;
    } catch (error) {
        console.error('File signature verification error:', error);
        return false;
    }
}

const storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        try {
            await fs.mkdir(tempUploadDir, { recursive: true });
            cb(null, tempUploadDir);
        } catch (error) {
            cb(error, null);
        }
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        const uniqueName = `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${ext}`;
        cb(null, uniqueName);
    }
});

const fileFilter = (req, file, cb) => {
    if (ALLOWED_FILE_TYPES.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('მხოლოდ სურათის ფაილებია დაშვებული (JPEG, PNG, GIF, WebP)'), false);
    }
};

const upload = multer({ 
    storage, 
    fileFilter, 
    limits: { 
        fileSize: MAX_FILE_SIZE,
        files: 1
    } 
});

app.post('/api/products/:id/image', authenticateToken, requireRole('admin', 'cellar_admin'), upload.single('image'), async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        if (isNaN(productId)) {
            if (req.file) await fs.unlink(req.file.path).catch(() => {});
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        const product = database.products.getById(productId);
        if (!product) {
            if (req.file) await fs.unlink(req.file.path).catch(() => {});
            return res.status(404).json({ error: 'პროდუქტი ვერ მოიძებნა' });
        }
        
        if (req.user.role === 'cellar_admin' && req.user.cellarId !== product.cellarId) {
            if (req.file) await fs.unlink(req.file.path).catch(() => {});
            return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
        }
        
        if (!req.file) {
            return res.status(400).json({ error: 'ფაილი არ აიტვირთა' });
        }
        
        // Magic bytes ვერიფიკაცია - რეალური ფაილის ტიპის შემოწმება
        const isValidFile = await verifyFileSignature(req.file.path, req.file.mimetype);
        if (!isValidFile) {
            await fs.unlink(req.file.path).catch(() => {});
            return res.status(400).json({ 
                error: 'არასწორი ფაილის ტიპი', 
                details: 'ფაილის შიგთავსი არ შეესაბამება დეკლარირებულ ტიპს' 
            });
        }
        
        if (product.image) {
            try {
                await fs.unlink(path.join(__dirname, product.image));
            } catch (e) {}
        }
        
        const cellarDir = path.join(DATA_DIR, 'cellars', `cellar_${product.cellarId}`, 'products');
        await fs.mkdir(cellarDir, { recursive: true });
        
        const newPath = path.join(cellarDir, req.file.filename);
        await fs.rename(req.file.path, newPath);
        
        const imageUrl = `/data/cellars/cellar_${product.cellarId}/products/${req.file.filename}`;
        database.products.updateImage(productId, imageUrl);
        
        const updatedProduct = database.products.getById(productId);
        res.json(updatedProduct);
    } catch (error) {
        console.error('სურათის ატვირთვის შეცდომა:', error);
        if (req.file) await fs.unlink(req.file.path).catch(() => {});
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.use('/data', express.static(DATA_DIR));

// ========== ORDERS API ==========

// Idempotency keys დუბლიკატი შეკვეთების პრევენციისთვის
const orderIdempotencyCache = new Map();
const IDEMPOTENCY_TTL = 5 * 60 * 1000; // 5 წუთი

// Idempotency cache-ის ავტომატური გასუფთავება
setInterval(() => {
    const now = Date.now();
    for (const [key, data] of orderIdempotencyCache.entries()) {
        if (now - data.timestamp > IDEMPOTENCY_TTL) {
            orderIdempotencyCache.delete(key);
        }
    }
}, 60 * 1000); // ყოველ წუთში

// Idempotency key-ის გენერაცია მომხმარებლის მონაცემებიდან
function generateIdempotencyKey(customer, items) {
    const data = JSON.stringify({
        name: customer.name,
        phone: customer.phone,
        items: items.map(i => ({ id: i.id, qty: i.quantity })).sort((a, b) => a.id - b.id)
    });
    return crypto.createHash('sha256').update(data).digest('hex').substring(0, 32);
}

app.post('/api/orders', async (req, res) => {
    try {
        const { customer, items, idempotencyKey: clientKey } = req.body;
        
        // ვალიდაცია
        if (!customer || !customer.name || !customer.phone) {
            return res.status(400).json({ error: 'სახელი და ტელეფონი სავალდებულოა' });
        }
        
        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'კალათა ცარიელია' });
        }
        
        // Idempotency შემოწმება - დუბლიკატი შეკვეთების პრევენცია
        const idempotencyKey = clientKey || generateIdempotencyKey(customer, items);
        const existingOrder = orderIdempotencyCache.get(idempotencyKey);
        
        if (existingOrder) {
            // დუბლიკატი მოთხოვნა - ვაბრუნებთ არსებულ შეკვეთას
            console.log(`⚠️ Duplicate order prevented: ${existingOrder.orderId}`);
            return res.status(200).json({
                success: true,
                orderId: existingOrder.orderId,
                totalAmount: existingOrder.totalAmount,
                duplicate: true,
                message: 'შეკვეთა უკვე შექმნილია'
            });
        }
        
        const customerName = sanitizeString(customer.name);
        const customerPhone = sanitizeString(customer.phone);
        
        if (customerName.length < 2 || customerName.length > 100) {
            return res.status(400).json({ error: 'სახელი: 2-100 სიმბოლო' });
        }
        
        if (!validatePhone(customerPhone)) {
            return res.status(400).json({ error: 'არასწორი ტელეფონის ნომერი' });
        }
        
        if (customer.email && !validateEmail(customer.email)) {
            return res.status(400).json({ error: 'არასწორი ელ.ფოსტა' });
        }
        
        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'კალათა ცარიელია' });
        }
        
        if (items.length > 50) {
            return res.status(400).json({ error: 'მაქსიმუმ 50 პროდუქტი' });
        }
        
        // რაოდენობის ვალიდაცია - უარყოფითი და ნულოვანი რაოდენობის შემოწმება
        for (const item of items) {
            const qty = parseInt(item.quantity);
            if (isNaN(qty) || qty <= 0) {
                return res.status(400).json({ 
                    error: 'არასწორი რაოდენობა', 
                    details: `პროდუქტის რაოდენობა უნდა იყოს დადებითი რიცხვი (მინიმუმ 1)` 
                });
            }
            if (qty > 1000) {
                return res.status(400).json({ 
                    error: 'რაოდენობა ზედმეტად დიდია', 
                    details: `მაქსიმუმ 1000 ერთეული ერთ პროდუქტზე` 
                });
            }
            // განვაახლოთ item.quantity რომ integer იყოს
            item.quantity = qty;
        }
        
        // მარაგის შემოწმება
        const outOfStock = [];
        for (const item of items) {
            const product = database.products.getById(item.id);
            if (!product) {
                return res.status(400).json({ error: `პროდუქტი ვერ მოიძებნა: ${item.name}` });
            }
            if (product.stock !== undefined && product.stock < item.quantity) {
                outOfStock.push({
                    name: product.name,
                    requested: item.quantity,
                    available: product.stock
                });
            }
        }
        
        if (outOfStock.length > 0) {
            return res.status(400).json({ 
                error: 'არასაკმარისი მარაგი',
                details: outOfStock.map(p => `${p.name}: მოთხოვნილია ${p.requested}, მარაგშია ${p.available}`).join('; '),
                outOfStock 
            });
        }
        
        const orderId = Date.now().toString(36).toUpperCase();
        let totalAmount = 0;
        
        const ordersBycellar = {};
        for (const item of items) {
            const product = database.products.getById(item.id);
            totalAmount += product.price * item.quantity;
            const cellarId = product.cellarId;
            
            if (!ordersBycellar[cellarId]) {
                const cellar = database.cellars.getById(cellarId);
                const cellarAdmin = database.users.getByCellarId(cellarId);
                ordersBycellar[cellarId] = {
                    cellar,
                    cellarEmail: cellarAdmin ? cellarAdmin.email : null,
                    items: [],
                    subtotal: 0
                };
            }
            ordersBycellar[cellarId].items.push({
                ...item,
                price: product.price,
                cellarName: product.cellarName
            });
            ordersBycellar[cellarId].subtotal += product.price * item.quantity;
        }
        
        const orderData = {
            id: orderId,
            customerName,
            customerPhone,
            customerEmail: customer.email ? sanitizeString(customer.email) : null,
            customerAddress: customer.address ? sanitizeString(customer.address) : null,
            customerComment: customer.comment ? sanitizeString(customer.comment).slice(0, 500) : null,
            totalAmount,
            status: 'pending',
            paymentStatus: 'pending',
            createdAt: new Date().toISOString()
        };
        
        const itemsData = items.map(item => {
            const product = database.products.getById(item.id);
            return {
                orderId,
                productId: item.id,
                productName: product.name,
                price: product.price,
                quantity: item.quantity,
                cellarId: product.cellarId,
                cellarName: product.cellarName
            };
        });
        
        database.createOrderWithItems(orderData, itemsData);
        console.log(`✅ შეკვეთა შენახულია: #${orderId} (${totalAmount}₾)`);
        
        // Low stock alerts
        for (const item of items) {
            await checkAndSendLowStockAlert(item.id);
        }
        
        // Email-ები (async, არ ველოდებით)
        const orderDate = new Date().toLocaleString('ka-GE', { timeZone: 'Asia/Tbilisi' });
        
        // მარნებს
        for (const cellarId in ordersBycellar) {
            const orderInfo = ordersBycellar[cellarId];
            if (orderInfo.cellarEmail) {
                const itemsHtml = orderInfo.items.map(item => `
                    <tr>
                        <td style="padding: 10px; border-bottom: 1px solid #eee;">${escapeHtml(item.name)}</td>
                        <td style="padding: 10px; text-align: center;">${item.quantity}</td>
                        <td style="padding: 10px; text-align: right;">${item.price}₾</td>
                        <td style="padding: 10px; text-align: right;">${(item.price * item.quantity).toFixed(2)}₾</td>
                    </tr>
                `).join('');
                
                const cellarHtml = `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                        <div style="background: #8B0000; color: white; padding: 20px; text-align: center;">
                            <h1>🍷 ახალი შეკვეთა!</h1>
                            <p>შეკვეთის ID: ${orderId}</p>
                        </div>
                        <div style="padding: 20px;">
                            <h2>👤 შემკვეთი</h2>
                            <p><strong>სახელი:</strong> ${escapeHtml(customerName)}</p>
                            <p><strong>ტელეფონი:</strong> ${escapeHtml(customerPhone)}</p>
                            ${customer.email ? `<p><strong>ელ.ფოსტა:</strong> ${escapeHtml(customer.email)}</p>` : ''}
                            ${customer.address ? `<p><strong>მისამართი:</strong> ${escapeHtml(customer.address)}</p>` : ''}
                            <h2>📦 პროდუქტები</h2>
                            <table style="width: 100%; border-collapse: collapse;">
                                <thead><tr style="background: #f5f5f5;">
                                    <th style="padding: 10px; text-align: left;">პროდუქტი</th>
                                    <th style="padding: 10px;">რაოდ.</th>
                                    <th style="padding: 10px; text-align: right;">ფასი</th>
                                    <th style="padding: 10px; text-align: right;">ჯამი</th>
                                </tr></thead>
                                <tbody>${itemsHtml}</tbody>
                            </table>
                            <p style="font-size: 1.2em; margin-top: 20px;"><strong>ჯამი: ${orderInfo.subtotal.toFixed(2)}₾</strong></p>
                            <p style="color: #666;">📅 ${orderDate}</p>
                        </div>
                    </div>
                `;
                
                sendEmail(
                    orderInfo.cellarEmail,
                    `🍷 ახალი შეკვეთა #${orderId} - ${orderInfo.subtotal.toFixed(2)}₾`,
                    cellarHtml
                ).catch(console.error);
            }
        }
        
        // WineLab-ს
        const allItemsHtml = itemsData.map(item => `
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #eee;">${escapeHtml(item.productName)}</td>
                <td style="padding: 10px;">${escapeHtml(item.cellarName)}</td>
                <td style="padding: 10px; text-align: center;">${item.quantity}</td>
                <td style="padding: 10px; text-align: right;">${(item.price * item.quantity).toFixed(2)}₾</td>
            </tr>
        `).join('');
        
        const winelabHtml = `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <div style="background: #8B0000; color: white; padding: 20px; text-align: center;">
                    <h1>🍷 ახალი შეკვეთა!</h1>
                    <p>შეკვეთის ID: ${orderId}</p>
                </div>
                <div style="padding: 20px;">
                    <h2>👤 შემკვეთი</h2>
                    <p><strong>სახელი:</strong> ${escapeHtml(customerName)}</p>
                    <p><strong>ტელეფონი:</strong> ${escapeHtml(customerPhone)}</p>
                    ${customer.email ? `<p><strong>ელ.ფოსტა:</strong> ${escapeHtml(customer.email)}</p>` : ''}
                    ${customer.address ? `<p><strong>მისამართი:</strong> ${escapeHtml(customer.address)}</p>` : ''}
                    <h2>📦 ყველა პროდუქტი</h2>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead><tr style="background: #f5f5f5;">
                            <th style="padding: 10px; text-align: left;">პროდუქტი</th>
                            <th style="padding: 10px;">მარანი</th>
                            <th style="padding: 10px;">რაოდ.</th>
                            <th style="padding: 10px; text-align: right;">ჯამი</th>
                        </tr></thead>
                        <tbody>${allItemsHtml}</tbody>
                        <tfoot><tr style="background: #8B0000; color: white;">
                            <td colspan="3" style="padding: 15px; font-weight: bold;">სულ:</td>
                            <td style="padding: 15px; text-align: right; font-weight: bold;">${totalAmount.toFixed(2)}₾</td>
                        </tr></tfoot>
                    </table>
                    <p style="color: #666; margin-top: 20px;">📅 ${orderDate}</p>
                </div>
            </div>
        `;
        
        sendEmail(WINELAB_EMAIL, `🍷 ახალი შეკვეთა #${orderId} - ${totalAmount.toFixed(2)}₾`, winelabHtml).catch(console.error);
        
        // Idempotency key-ის შენახვა cache-ში
        orderIdempotencyCache.set(idempotencyKey, {
            orderId,
            totalAmount,
            timestamp: Date.now()
        });
        
        res.json({ success: true, orderId, totalAmount, message: 'შეკვეთა წარმატებით გაიგზავნა' });
    } catch (error) {
        console.error('შეკვეთის შეცდომა:', error);
        res.status(500).json({ error: 'შეკვეთის გაგზავნა ვერ მოხერხდა' });
    }
});

// ========== ORDERS READ/UPDATE ==========
app.get('/api/orders', authenticateToken, requireRole('admin'), (req, res) => {
    try {
        const orders = database.getAllOrdersWithItems();
        res.json(orders);
    } catch (error) {
        console.error('შეკვეთების ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.get('/api/orders/track/:orderId', (req, res) => {
    try {
        const orderId = sanitizeString(req.params.orderId).toUpperCase();
        if (!orderId || orderId.length > 20) {
            return res.status(400).json({ error: 'არასწორი შეკვეთის ID' });
        }
        
        const order = database.getOrderWithItems(orderId);
        if (!order) {
            return res.status(404).json({ error: 'შეკვეთა ვერ მოიძებნა' });
        }
        
        // მარნების საბანკო ინფორმაციის მიღება გადახდისთვის
        const cellarIds = [...new Set(order.items.map(i => i.cellarId))];
        const cellarsPaymentInfo = {};
        for (const cellarId of cellarIds) {
            const cellar = database.cellars.getById(cellarId);
            if (cellar && !cellar.hidden) {
                cellarsPaymentInfo[cellarId] = {
                    id: cellar.id,
                    name: cellar.name,
                    iban: cellar.iban,
                    bankName: cellar.bankName,
                    accountHolder: cellar.accountHolder
                };
            }
        }
        
        res.json({
            id: order.id,
            status: order.status,
            paymentStatus: order.paymentStatus,
            totalAmount: order.totalAmount,
            customerName: order.customerName,
            customerPhone: order.customerPhone ? order.customerPhone.replace(/(\d{3})\d{3}(\d{3})/, '$1***$2') : null,
            customerAddress: order.customerAddress,
            createdAt: order.createdAt,
            items: order.items.map(item => ({
                productName: item.productName,
                cellarId: item.cellarId,
                cellarName: item.cellarName,
                quantity: item.quantity,
                price: item.price
            })),
            cellarsPaymentInfo
        });
    } catch (error) {
        console.error('თრექინგის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.get('/api/orders/cellar/:cellarId', authenticateToken, requireRole('admin', 'cellar_admin'), (req, res) => {
    try {
        const cellarId = parseInt(req.params.cellarId);
        if (isNaN(cellarId)) {
            return res.status(400).json({ error: 'არასწორი ID' });
        }
        
        if (req.user.role === 'cellar_admin' && req.user.cellarId !== cellarId) {
            return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
        }
        
        const orders = database.getCellarOrders(cellarId);
        res.json(orders);
    } catch (error) {
        console.error('შეკვეთების ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.get('/api/orders/:orderId', authenticateToken, requireRole('admin', 'cellar_admin'), (req, res) => {
    try {
        const order = database.getOrderWithItems(req.params.orderId);
        if (!order) {
            return res.status(404).json({ error: 'შეკვეთა ვერ მოიძებნა' });
        }
        
        if (req.user.role === 'cellar_admin') {
            const hasAccess = order.items.some(item => item.cellarId === req.user.cellarId);
            if (!hasAccess) {
                return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
            }
        }
        
        res.json(order);
    } catch (error) {
        console.error('შეკვეთის ჩატვირთვის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.put('/api/orders/:orderId/status', authenticateToken, requireRole('admin', 'cellar_admin'), (req, res) => {
    try {
        const { status } = req.body;
        const validStatuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];
        
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ error: 'არასწორი სტატუსი' });
        }
        
        const order = database.getOrderWithItems(req.params.orderId);
        if (!order) {
            return res.status(404).json({ error: 'შეკვეთა ვერ მოიძებნა' });
        }
        
        if (req.user.role === 'cellar_admin') {
            const hasAccess = order.items.some(item => item.cellarId === req.user.cellarId);
            if (!hasAccess) {
                return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
            }
        }
        
        database.orders.updateStatus(req.params.orderId, status);
        const updatedOrder = database.getOrderWithItems(req.params.orderId);
        console.log(`✅ შეკვეთის სტატუსი: #${req.params.orderId} -> ${status}`);
        res.json(updatedOrder);
    } catch (error) {
        console.error('სტატუსის განახლების შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

app.put('/api/orders/:orderId/payment', authenticateToken, requireRole('admin', 'cellar_admin'), (req, res) => {
    try {
        const { paymentStatus } = req.body;
        const validStatuses = ['pending', 'paid'];
        
        if (!validStatuses.includes(paymentStatus)) {
            return res.status(400).json({ error: 'არასწორი გადახდის სტატუსი' });
        }
        
        const order = database.getOrderWithItems(req.params.orderId);
        if (!order) {
            return res.status(404).json({ error: 'შეკვეთა ვერ მოიძებნა' });
        }
        
        if (req.user.role === 'cellar_admin') {
            const hasAccess = order.items.some(item => item.cellarId === req.user.cellarId);
            if (!hasAccess) {
                return res.status(403).json({ error: 'არასაკმარისი უფლებები' });
            }
        }
        
        database.orders.updatePaymentStatus(req.params.orderId, paymentStatus);
        const updatedOrder = database.getOrderWithItems(req.params.orderId);
        console.log(`✅ გადახდა: #${req.params.orderId} -> ${paymentStatus}`);
        res.json(updatedOrder);
    } catch (error) {
        console.error('გადახდის განახლების შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

// ========== STATISTICS ==========
app.get('/api/stats/orders', authenticateToken, requireRole('admin'), (req, res) => {
    try {
        const orders = database.getAllOrdersWithItems();
        const cellars = database.cellars.getAll();
        
        const totalOrders = orders.length;
        const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
        const paidOrders = orders.filter(o => o.paymentStatus === 'paid');
        const paidRevenue = paidOrders.reduce((sum, o) => sum + o.totalAmount, 0);
        
        const cellarStats = cellars.map(cellar => {
            const cellarOrders = orders.filter(o => o.items.some(i => i.cellarId === cellar.id));
            const cellarRevenue = cellarOrders.reduce((sum, o) => {
                return sum + o.items.filter(i => i.cellarId === cellar.id)
                    .reduce((s, i) => s + i.price * i.quantity, 0);
            }, 0);
            const paidCellarOrders = cellarOrders.filter(o => o.paymentStatus === 'paid');
            const paidCellarRevenue = paidCellarOrders.reduce((sum, o) => {
                return sum + o.items.filter(i => i.cellarId === cellar.id)
                    .reduce((s, i) => s + i.price * i.quantity, 0);
            }, 0);
            
            return {
                cellarId: cellar.id,
                cellarName: cellar.name,
                totalOrders: cellarOrders.length,
                paidOrders: paidCellarOrders.length,
                totalItems: cellarOrders.reduce((sum, o) => 
                    sum + o.items.filter(i => i.cellarId === cellar.id).reduce((s, i) => s + i.quantity, 0), 0),
                totalRevenue: cellarRevenue,
                paidRevenue: paidCellarRevenue
            };
        }).sort((a, b) => b.totalRevenue - a.totalRevenue);
        
        // რეიტინგის გამოთვლა (1-5 ვარსკვლავი)
        const maxRevenue = Math.max(...cellarStats.map(s => s.totalRevenue), 1);
        const cellarStatsWithRating = cellarStats.map(stat => {
            let rating;
            if (stat.totalRevenue === 0) {
                rating = 0; // არ აქვს გაყიდვები
            } else {
                const revenuePercent = (stat.totalRevenue / maxRevenue) * 100;
                if (revenuePercent >= 80) rating = 5;
                else if (revenuePercent >= 60) rating = 4;
                else if (revenuePercent >= 40) rating = 3;
                else if (revenuePercent >= 20) rating = 2;
                else rating = 1;
            }
            return { ...stat, rating };
        });
        
        res.json({ 
            totalOrders, 
            totalRevenue, 
            paidOrders: paidOrders.length,
            paidRevenue,
            pendingRevenue: totalRevenue - paidRevenue,
            cellarStats: cellarStatsWithRating 
        });
    } catch (error) {
        console.error('სტატისტიკის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

// გადახდების სტატისტიკა
app.get('/api/stats/payments', authenticateToken, requireRole('admin'), (req, res) => {
    try {
        const orders = database.getAllOrdersWithItems();
        
        const paid = orders.filter(o => o.paymentStatus === 'paid');
        const pending = orders.filter(o => o.paymentStatus === 'pending');
        
        // UniPay გადახდები
        const unipayPayments = orders.filter(o => o.unipayPaymentId);
        const unipayPaid = unipayPayments.filter(o => o.paymentStatus === 'paid');
        
        // დღეების მიხედვით (ბოლო 30 დღე)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const recentPaid = paid.filter(o => new Date(o.paidAt || o.createdAt) >= thirtyDaysAgo);
        const dailyStats = {};
        
        recentPaid.forEach(order => {
            const date = (order.paidAt || order.createdAt).split('T')[0];
            if (!dailyStats[date]) {
                dailyStats[date] = { count: 0, amount: 0 };
            }
            dailyStats[date].count++;
            dailyStats[date].amount += order.totalAmount;
        });
        
        res.json({
            summary: {
                totalPaid: paid.length,
                totalPending: pending.length,
                paidAmount: paid.reduce((sum, o) => sum + o.totalAmount, 0),
                pendingAmount: pending.reduce((sum, o) => sum + o.totalAmount, 0)
            },
            unipay: {
                total: unipayPayments.length,
                paid: unipayPaid.length,
                amount: unipayPaid.reduce((sum, o) => sum + o.totalAmount, 0)
            },
            daily: dailyStats,
            recentPayments: paid
                .sort((a, b) => new Date(b.paidAt || b.createdAt) - new Date(a.paidAt || a.createdAt))
                .slice(0, 20)
                .map(o => ({
                    orderId: o.id,
                    amount: o.totalAmount,
                    customerName: o.customer.name,
                    paidAt: o.paidAt,
                    unipayPaymentId: o.unipayPaymentId || null,
                    method: o.unipayPaymentId ? 'UniPay' : 'Manual'
                }))
        });
    } catch (error) {
        console.error('გადახდების სტატისტიკის შეცდომა:', error);
        res.status(500).json({ error: 'სერვერის შეცდომა' });
    }
});

// ========== ERROR HANDLER ==========
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    
    if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({ error: 'ფაილი ძალიან დიდია (მაქს. 5MB)' });
        }
        return res.status(400).json({ error: 'ფაილის ატვირთვის შეცდომა' });
    }
    
    res.status(500).json({ error: 'სერვერის შეცდომა' });
});

// ========== UNIPAY INTEGRATION ==========
const unipayConfig = require('./unipay-config');
const fetch = require('node-fetch');

// UniPay კონფიგურაციის მიღება
function getUnipayConfig() {
    const config = unipayConfig[unipayConfig.mode];
    return {
        ...config,
        mode: unipayConfig.mode,
        currency: unipayConfig.currency,
        endpoints: unipayConfig.endpoints
    };
}

// UniPay-ზე გადახდის შექმნა
app.post('/api/unipay/create-payment', async (req, res) => {
    try {
        const { orderId, amount, description } = req.body;
        
        if (!orderId || !amount) {
            return res.status(400).json({ error: 'orderId და amount სავალდებულოა' });
        }
        
        // ვალიდაცია
        if (typeof amount !== 'number' || amount <= 0 || amount > 100000) {
            return res.status(400).json({ error: 'არასწორი თანხა' });
        }
        
        const order = database.orders.getByOrderId(orderId);
        if (!order) {
            return res.status(404).json({ error: 'შეკვეთა ვერ მოიძებნა' });
        }
        
        // თუ უკვე გადახდილია
        if (order.paymentStatus === 'paid') {
            return res.status(400).json({ error: 'შეკვეთა უკვე გადახდილია' });
        }
        
        const config = getUnipayConfig();
        const baseUrl = `${req.protocol}://${req.get('host')}`;
        const callbacks = unipayConfig.getCallbackUrls(baseUrl);
        
        // Sandbox mode - დემო გვერდზე გადამისამართება
        if (config.mode === 'sandbox') {
            const demoPaymentId = `DEMO_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
            
            // შევინახოთ demo payment ID
            database.orders.updatePaymentId(orderId, demoPaymentId);
            
            console.log(`📋 UniPay SANDBOX: შეკვეთა #${orderId}, თანხა: ${amount}₾`);
            
            return res.json({
                success: true,
                paymentId: demoPaymentId,
                // დემო რეჟიმში გადავამისამართოთ success გვერდზე პირდაპირ
                checkoutUrl: `${baseUrl}/payment-success.html?orderId=${orderId}&demo=true`,
                mode: 'sandbox',
                message: 'სატესტო რეჟიმი - გადახდა სიმულირებულია'
            });
        }
        
        // Production mode - რეალური API call
        if (!config.merchantId || !config.secretKey) {
            return res.status(503).json({ 
                error: 'UniPay არ არის კონფიგურირებული',
                hint: 'დაამატეთ UNIPAY_MERCHANT_ID და UNIPAY_SECRET_KEY .env ფაილში'
            });
        }
        
        const requestBody = {
            MerchantId: config.merchantId,
            Amount: Math.round(amount * 100), // თეთრებში
            Currency: config.currency,
            OrderId: orderId,
            Description: sanitizeString(description) || `WineLab შეკვეთა #${orderId}`,
            SuccessUrl: callbacks.successUrl + `?orderId=${orderId}`,
            FailUrl: callbacks.failUrl + `?orderId=${orderId}`,
            CallbackUrl: callbacks.callbackUrl,
            Language: 'ka' // ქართული ინტერფეისი
        };
        
        console.log(`🔄 UniPay API: შეკვეთა #${orderId}, თანხა: ${amount}₾`);
        
        const response = await fetch(`${config.baseUrl}${config.endpoints.createOrder}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${config.secretKey}`,
                'Accept': 'application/json'
            },
            body: JSON.stringify(requestBody),
            timeout: 30000 // 30 წამი timeout
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(`UniPay API error ${response.status}:`, errorText);
            throw new Error(`UniPay API error: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.PaymentId && result.CheckoutUrl) {
            database.orders.updatePaymentId(orderId, result.PaymentId);
            console.log(`✅ UniPay payment created: ${result.PaymentId}`);
            
            res.json({ 
                success: true, 
                paymentId: result.PaymentId, 
                checkoutUrl: result.CheckoutUrl, 
                mode: 'production' 
            });
        } else {
            throw new Error(result.Message || result.error || 'UniPay შეცდომა');
        }
    } catch (error) {
        console.error('UniPay create-payment error:', error.message);
        res.status(500).json({ 
            error: 'გადახდის შექმნა ვერ მოხერხდა',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// UniPay Callback (Webhook)
// Callback-ების rate limiting - მაქსიმუმ 10 callback წუთში ერთი შეკვეთისთვის
const callbackRateLimit = new Map();

app.post('/api/unipay/callback', express.raw({ type: '*/*' }), async (req, res) => {
    try {
        // Parse body
        let payload;
        if (Buffer.isBuffer(req.body)) {
            payload = JSON.parse(req.body.toString());
        } else if (typeof req.body === 'object') {
            payload = req.body;
        } else {
            payload = JSON.parse(req.body);
        }
        
        console.log('📥 UniPay Callback received:', JSON.stringify(payload, null, 2));
        
        const { PaymentId, OrderId, Status, Amount, Signature } = payload;
        
        if (!OrderId) {
            console.warn('UniPay callback: missing OrderId');
            return res.status(400).json({ error: 'Missing OrderId' });
        }
        
        // Rate limiting callback-ებისთვის
        const rateLimitKey = `callback:${OrderId}`;
        const rateData = callbackRateLimit.get(rateLimitKey) || { count: 0, timestamp: Date.now() };
        
        // გავასუფთავოთ ძველი მონაცემები (1 წუთზე მეტი)
        if (Date.now() - rateData.timestamp > 60000) {
            rateData.count = 0;
            rateData.timestamp = Date.now();
        }
        
        rateData.count++;
        callbackRateLimit.set(rateLimitKey, rateData);
        
        if (rateData.count > 10) {
            console.warn(`⚠️ UniPay callback rate limit exceeded for order: ${OrderId}`);
            return res.status(429).json({ error: 'Too many callbacks', retryAfter: 60 });
        }
        
        // Signature verification
        const config = getUnipayConfig();
        
        // Production-ში სავალდებულოა signature
        if (config.mode === 'production') {
            if (!Signature) {
                console.error('UniPay callback: missing signature in production mode');
                return res.status(403).json({ error: 'Signature required' });
            }
            
            const isValid = unipayConfig.verifySignature(
                { PaymentId, OrderId, Status, Amount },
                Signature,
                config.secretKey
            );
            if (!isValid) {
                console.error('UniPay callback: invalid signature');
                return res.status(403).json({ error: 'Invalid signature' });
            }
            console.log('✅ UniPay signature verified');
        } else {
            // Sandbox mode - გაფრთხილება ლოგში
            if (!Signature) {
                console.warn('⚠️ UniPay callback without signature (sandbox mode - OK for testing)');
            }
        }
        
        const order = database.orders.getByOrderId(OrderId);
        if (!order) {
            console.warn(`UniPay callback: order not found: ${OrderId}`);
            return res.status(404).json({ error: 'Order not found' });
        }
        
        // სტატუსის განახლება
        const successStatuses = ['Completed', 'Success', 'Paid', 'COMPLETED', 'SUCCESS', 'PAID'];
        const failedStatuses = ['Failed', 'Declined', 'Cancelled', 'FAILED', 'DECLINED', 'CANCELLED'];
        
        if (successStatuses.includes(Status)) {
            database.orders.updatePaymentStatus(OrderId, 'paid');
            database.orders.updateStatus(OrderId, 'confirmed');
            console.log(`✅ UniPay: შეკვეთა #${OrderId} გადახდილია`);
            
            // შეკვეთის დადასტურების email (optional)
            try {
                if (order.customerEmail) {
                    await sendEmail(
                        order.customerEmail,
                        `✅ გადახდა დადასტურებულია - შეკვეთა #${OrderId}`,
                        `<div style="font-family: Arial, sans-serif;">
                            <h2>გადახდა წარმატებით დასრულდა!</h2>
                            <p>შეკვეთა: <strong>#${OrderId}</strong></p>
                            <p>თანხა: <strong>${(Amount / 100).toFixed(2)}₾</strong></p>
                            <p>მადლობა შეძენისთვის!</p>
                        </div>`
                    );
                }
            } catch (emailError) {
                console.error('Email sending failed:', emailError.message);
            }
        } else if (failedStatuses.includes(Status)) {
            console.log(`❌ UniPay: შეკვეთა #${OrderId} გადახდა ვერ მოხერხდა: ${Status}`);
        } else {
            console.log(`ℹ️ UniPay: შეკვეთა #${OrderId} სტატუსი: ${Status}`);
        }
        
        res.json({ status: 'ok', received: true });
    } catch (error) {
        console.error('UniPay callback error:', error);
        res.status(500).json({ error: 'Callback processing failed' });
    }
});

// გადახდის სტატუსის შემოწმება
app.get('/api/unipay/status/:orderId', async (req, res) => {
    try {
        const orderId = sanitizeString(req.params.orderId).toUpperCase();
        const order = database.orders.getByOrderId(orderId);
        
        if (!order) {
            return res.status(404).json({ error: 'შეკვეთა ვერ მოიძებნა' });
        }
        
        // თუ production-ია და გვაქვს paymentId, შევამოწმოთ UniPay-ზეც
        const config = getUnipayConfig();
        let unipayStatus = null;
        
        if (config.mode === 'production' && order.unipayPaymentId && config.merchantId) {
            try {
                const statusUrl = `${config.baseUrl}${config.endpoints.orderStatus.replace('{orderId}', order.unipayPaymentId)}`;
                const response = await fetch(statusUrl, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${config.secretKey}`,
                        'Accept': 'application/json'
                    },
                    timeout: 10000
                });
                
                if (response.ok) {
                    unipayStatus = await response.json();
                }
            } catch (e) {
                console.warn('UniPay status check failed:', e.message);
            }
        }
        
        res.json({
            orderId: order.id,
            paymentStatus: order.paymentStatus,
            orderStatus: order.status,
            totalAmount: order.totalAmount,
            unipayPaymentId: order.unipayPaymentId || null,
            unipayStatus: unipayStatus,
            paidAt: order.paidAt
        });
    } catch (error) {
        console.error('Status check error:', error);
        res.status(500).json({ error: 'სტატუსის შემოწმება ვერ მოხერხდა' });
    }
});

// UniPay კონფიგურაციის ინფორმაცია
app.get('/api/unipay/config', (req, res) => {
    const config = getUnipayConfig();
    res.json({
        enabled: config.mode === 'sandbox' || (!!config.merchantId && !!config.secretKey),
        mode: config.mode,
        currency: config.currency,
        merchantConfigured: !!config.merchantId,
        paymentMethods: unipayConfig.paymentMethods
    });
});

// Demo mode - გადახდის სიმულაცია (მხოლოდ sandbox-ში)
app.post('/api/unipay/simulate-payment', async (req, res) => {
    try {
        const config = getUnipayConfig();
        if (config.mode !== 'sandbox') {
            return res.status(403).json({ error: 'მხოლოდ sandbox რეჟიმში' });
        }
        
        const { orderId, success } = req.body;
        if (!orderId) {
            return res.status(400).json({ error: 'orderId საჭიროა' });
        }
        
        const order = database.orders.getByOrderId(orderId);
        if (!order) {
            return res.status(404).json({ error: 'შეკვეთა ვერ მოიძებნა' });
        }
        
        if (success !== false) {
            database.orders.updatePaymentStatus(orderId, 'paid');
            database.orders.updateStatus(orderId, 'confirmed');
            console.log(`✅ DEMO: შეკვეთა #${orderId} გადახდილია (სიმულაცია)`);
        } else {
            console.log(`❌ DEMO: შეკვეთა #${orderId} გადახდა უარყოფილია (სიმულაცია)`);
        }
        
        res.json({ 
            success: true, 
            message: success !== false ? 'გადახდა სიმულირებულია' : 'გადახდა უარყოფილია',
            orderId 
        });
    } catch (error) {
        res.status(500).json({ error: 'სიმულაციის შეცდომა' });
    }
});

// 404 handler (უნდა იყოს ბოლოს!)
app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
        return res.status(404).json({ error: 'Endpoint ვერ მოიძებნა' });
    }
    res.status(404).sendFile(path.join(__dirname, 'index.html'));
});

// ========== START SERVER ==========
const http = require('http');
const https = require('https');
const fsSync = require('fs');

async function startServer() {
    await initRedis();
    
    http.createServer(app).listen(PORT, () => {
        console.log(`📍 HTTP: http://localhost:${PORT}`);
    });

    const sslDir = path.join(__dirname, 'ssl');
    const keyPath = path.join(sslDir, 'key.pem');
    const certPath = path.join(sslDir, 'cert.pem');

    if (fsSync.existsSync(keyPath) && fsSync.existsSync(certPath)) {
        const httpsOptions = {
            key: fsSync.readFileSync(keyPath),
            cert: fsSync.readFileSync(certPath)
        };
        
        https.createServer(httpsOptions, app).listen(HTTPS_PORT, () => {
            console.log(`🔒 HTTPS: https://localhost:${HTTPS_PORT}`);
        });
    }

    console.log('═'.repeat(50));
    console.log('🍷 WineLab სერვერი გაშვებულია');
    console.log(`📁 მონაცემები: ${DATA_DIR}/winelab.db`);
    console.log(`🔐 Auth: JWT + ${useRedis ? 'Redis' : 'Memory'}`);
    console.log(`🛡️  Security: Helmet + Bcrypt + Rate Limiting`);
    console.log(`⚡ Rate Limit: ${RATE_LIMIT_MAX}/min, Auth: ${RATE_LIMIT_AUTH_MAX}/min`);
    console.log('═'.repeat(50));
}

startServer().catch(console.error);
