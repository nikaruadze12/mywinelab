// ========== მარნის ადმინის პანელი ==========
let myProducts = [];
let myOrders = [];
let currentUser = null;

console.log('cellar-admin.js loaded');

// ინიციალიზაცია
async function initCellarAdminPanel() {
    console.log('initCellarAdminPanel started');
    
    // JWT auth შემოწმება
    const isAuth = await checkAuthOnLoad('cellar_admin');
    if (!isAuth) return;
    
    currentUser = getCurrentUser();
    console.log('Current user:', currentUser);
    
    if (!currentUser || !currentUser.cellarId) {
        showNotification('მარანი არ არის მინიჭებული', 'error');
        logout();
        return;
    }
    
    await loadMyProducts();
    await loadMyOrders();
    renderMyProducts();
    renderMyOrders();
    
    // Event delegation for dynamic elements
    setupEventDelegation();
    
    console.log('initCellarAdminPanel completed');
}

// Event Delegation - ერთი listener მთელი ცხრილისთვის
function setupEventDelegation() {
    const productsTable = document.getElementById('productsTableBody');
    if (productsTable) {
        productsTable.addEventListener('click', handleProductTableClick);
    }
    
    const ordersTable = document.getElementById('ordersTableBody');
    if (ordersTable) {
        ordersTable.addEventListener('click', handleOrderTableClick);
    }
}

function handleProductTableClick(e) {
    const target = e.target.closest('[data-action]');
    if (!target) return;
    
    const action = target.dataset.action;
    const productId = parseInt(target.dataset.id);
    
    console.log('Product action:', action, 'ID:', productId);
    
    switch(action) {
        case 'upload-image':
            openImageUploadModal(productId);
            break;
        case 'edit':
            editProduct(productId);
            break;
        case 'delete':
            deleteProduct(productId);
            break;
    }
}

function handleOrderTableClick(e) {
    const row = e.target.closest('[data-order-id]');
    if (row) {
        const orderId = row.dataset.orderId;
        showOrderDetail(orderId);
    }
}

// ========== ტაბების მართვა ==========
function switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    document.querySelector(`[data-tab="${tabName}"]`)?.classList.add('active');
    document.getElementById(`${tabName}Tab`)?.classList.add('active');
}

// ========== პროდუქტები ==========
async function loadMyProducts() {
    if (!currentUser) currentUser = getCurrentUser();
    try {
        myProducts = await apiCall(`/products/cellar/${currentUser.cellarId}`);
        console.log('Loaded products:', myProducts.length);
    } catch (error) {
        console.error('პროდუქტების ჩატვირთვის შეცდომა:', error);
        myProducts = [];
    }
}

function renderMyProducts() {
    const tbody = document.getElementById('productsTableBody');
    if (!tbody) return;
    
    if (myProducts.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">პროდუქტები არ არის დამატებული</td></tr>';
        return;
    }
    
    tbody.innerHTML = myProducts.map(product => {
        const category = product.category || 'wine';
        let icon, typeDisplay, badgeClass;
        
        if (category === 'spirit') {
            icon = '🥃';
            typeDisplay = getSpiritTypeName(product.spiritType) + ` ${product.alcoholContent || 40}%`;
            badgeClass = 'spirit';
        } else if (category === 'grape') {
            icon = '🍇';
            typeDisplay = getGrapeTypeName(product.grapeProductType);
            badgeClass = 'grape';
        } else {
            icon = '🍷';
            typeDisplay = getWineTypeName(product.color, product.sugar);
            badgeClass = product.color || 'white';
        }
        
        const stock = product.stock !== undefined ? product.stock : '-';
        const stockClass = stock === 0 ? 'stock-out' : (stock <= 10 ? 'stock-low' : 'stock-ok');
        
        return `
            <tr>
                <td>
                    <div class="product-thumb" data-action="upload-image" data-id="${product.id}" style="cursor:pointer" title="სურათის ატვირთვა">
                        ${product.image 
                            ? `<img src="${product.image}" alt="${escapeHtmlSafe(product.name)}" loading="lazy">` 
                            : `<span class="no-image">${icon}</span>`}
                    </div>
                </td>
                <td><strong>${escapeHtmlSafe(product.name)}</strong></td>
                <td class="hide-mobile"><span class="badge badge-${badgeClass}">${typeDisplay}</span></td>
                <td><strong>${product.price}₾</strong></td>
                <td><span class="stock-badge ${stockClass}">${stock === 0 ? 'ამოიწურა' : stock}</span></td>
                <td class="hide-mobile">${product.year || '-'}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn-icon" data-action="edit" data-id="${product.id}" title="რედაქტირება">✏️</button>
                        <button class="btn-icon btn-danger" data-action="delete" data-id="${product.id}" title="წაშლა">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// ტიპების სახელები
function getWineTypeName(color, sugar) {
    const colors = { white: 'თეთრი', amber: 'ქარვისფერი', rose: 'ვარდისფერი', red: 'წითელი' };
    const sugars = { dry: 'მშრალი', 'semi-dry': 'ნახევრადმშრალი', 'semi-sweet': 'ნახევრადტკბილი', sweet: 'ტკბილი' };
    return `${colors[color] || color || ''} ${sugars[sugar] || sugar || ''}`.trim();
}

function getSpiritTypeName(type) {
    const types = { 'chacha': 'ჭაჭა', 'araki': 'არაყი', 'brandy': 'ბრენდი', 'whiskey': 'ვისკი', 'vodka': 'არაყი/ვოდკა' };
    return types[type] || type || '';
}

function getGrapeTypeName(type) {
    const types = { 'churchkhela': 'ჩურჩხელა', 'badagi': 'ბადაგი', 'grape_seed_oil': 'წიპწის ზეთი' };
    return types[type] || type || '';
}

function escapeHtmlSafe(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========== შეკვეთები ==========
async function loadMyOrders() {
    if (!currentUser) currentUser = getCurrentUser();
    try {
        myOrders = await apiCall(`/orders/cellar/${currentUser.cellarId}`);
        updateOrdersCount();
    } catch (error) {
        console.error('შეკვეთების ჩატვირთვის შეცდომა:', error);
        myOrders = [];
    }
}

function updateOrdersCount() {
    const badge = document.getElementById('ordersCount');
    if (badge) {
        const pendingCount = myOrders.filter(o => o.status === 'pending').length;
        badge.textContent = pendingCount;
        badge.style.display = pendingCount > 0 ? 'inline-flex' : 'none';
    }
}

function renderMyOrders() {
    const tbody = document.getElementById('ordersTableBody');
    if (!tbody) return;
    
    if (myOrders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">შეკვეთები ჯერ არ არის</td></tr>';
        return;
    }
    
    tbody.innerHTML = myOrders.map(order => {
        const isPaid = order.paymentStatus === 'paid';
        return `
            <tr class="order-row ${order.status}" data-order-id="${order.id}" style="cursor:pointer">
                <td><code>#${order.id}</code></td>
                <td>
                    <div class="customer-info">
                        <strong>${escapeHtmlSafe(order.customer.name)}</strong>
                        <small>${escapeHtmlSafe(order.customer.phone)}</small>
                    </div>
                </td>
                <td class="hide-mobile">${order.items.length} პროდუქტი</td>
                <td><strong>${order.cellarTotal?.toFixed(2) || order.totalAmount?.toFixed(2)}₾</strong></td>
                <td>
                    <span class="payment-badge ${isPaid ? 'payment-paid' : 'payment-pending'}">
                        ${isPaid ? '✅ გადახდილი' : '⏳ მოლოდინში'}
                    </span>
                </td>
                <td><span class="status-badge status-${order.status}">${getStatusName(order.status)}</span></td>
                <td class="hide-mobile">${formatDateLocal(order.createdAt)}</td>
            </tr>
        `;
    }).join('');
}

function getStatusName(status) {
    const statuses = { 'pending': 'მოლოდინში', 'confirmed': 'დადასტურებული', 'shipped': 'გაგზავნილი', 'delivered': 'მიწოდებული', 'cancelled': 'გაუქმებული' };
    return statuses[status] || status;
}

function formatDateLocal(dateStr) {
    return new Date(dateStr).toLocaleDateString('ka-GE', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function showOrderDetail(orderId) {
    const order = myOrders.find(o => o.id === orderId);
    if (!order) return;
    
    const isPaid = order.paymentStatus === 'paid';
    
    const content = document.getElementById('orderDetailContent');
    content.innerHTML = `
        <div class="order-detail">
            <div class="order-section">
                <h3>👤 მომხმარებელი</h3>
                <p><strong>სახელი:</strong> ${escapeHtmlSafe(order.customer.name)}</p>
                <p><strong>ტელეფონი:</strong> <a href="tel:${order.customer.phone}">${order.customer.phone}</a></p>
                ${order.customer.email ? `<p><strong>ელ.ფოსტა:</strong> ${order.customer.email}</p>` : ''}
                ${order.customer.address ? `<p><strong>მისამართი:</strong> ${order.customer.address}</p>` : ''}
            </div>
            <div class="order-section">
                <h3>📦 პროდუქტები</h3>
                ${order.items.map(item => `<div class="order-item"><span>${escapeHtmlSafe(item.name)} × ${item.quantity}</span><span>${(item.price * item.quantity).toFixed(2)}₾</span></div>`).join('')}
                <div class="order-total"><strong>სულ: ${order.cellarTotal?.toFixed(2) || order.totalAmount?.toFixed(2)}₾</strong></div>
            </div>
            <div class="order-section">
                <h3>💳 გადახდის სტატუსი</h3>
                <select id="paymentStatusSelect" class="status-select">
                    <option value="pending" ${!isPaid ? 'selected' : ''}>⏳ მოლოდინში</option>
                    <option value="paid" ${isPaid ? 'selected' : ''}>✅ გადახდილი</option>
                </select>
            </div>
            <div class="order-section">
                <h3>📋 შეკვეთის სტატუსი</h3>
                <select id="orderStatusSelect" class="status-select">
                    <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>მოლოდინში</option>
                    <option value="confirmed" ${order.status === 'confirmed' ? 'selected' : ''}>დადასტურებული</option>
                    <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>გაგზავნილი</option>
                    <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>მიწოდებული</option>
                    <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>გაუქმებული</option>
                </select>
            </div>
        </div>
    `;
    
    // Event listeners
    document.getElementById('orderStatusSelect').addEventListener('change', function() {
        updateOrderStatus(orderId, this.value);
    });
    
    document.getElementById('paymentStatusSelect').addEventListener('change', function() {
        updatePaymentStatus(orderId, this.value);
    });
    
    document.getElementById('orderDetailModal').style.display = 'flex';
}

async function updatePaymentStatus(orderId, paymentStatus) {
    try {
        await apiCall(`/orders/${orderId}/payment`, { method: 'PUT', body: JSON.stringify({ paymentStatus }) });
        const order = myOrders.find(o => o.id === orderId);
        if (order) order.paymentStatus = paymentStatus;
        renderMyOrders();
        showNotification('გადახდის სტატუსი განახლდა', 'success');
    } catch (error) {
        console.error('Payment status error:', error);
        showNotification('შეცდომა: ' + error.message, 'error');
    }
}

async function updateOrderStatus(orderId, status) {
    try {
        await apiCall(`/orders/${orderId}/status`, { method: 'PUT', body: JSON.stringify({ status }) });
        const order = myOrders.find(o => o.id === orderId);
        if (order) order.status = status;
        renderMyOrders();
        showNotification('სტატუსი განახლდა', 'success');
    } catch (error) {
        showNotification('შეცდომა', 'error');
    }
}

// ========== კატეგორიის ველები ==========
function toggleCategoryFields() {
    const category = document.getElementById('productCategory')?.value || 'wine';
    const wineFields = document.getElementById('wineFields');
    const spiritFields = document.getElementById('spiritFields');
    const grapeFields = document.getElementById('grapeFields');
    
    if (wineFields) wineFields.style.display = category === 'wine' ? 'block' : 'none';
    if (spiritFields) spiritFields.style.display = category === 'spirit' ? 'block' : 'none';
    if (grapeFields) grapeFields.style.display = category === 'grape' ? 'block' : 'none';
}

// ========== პროდუქტის დამატება ==========
function openAddProductModal() {
    console.log('openAddProductModal called');
    const form = document.getElementById('addProductForm');
    if (form) form.reset();
    
    const categorySelect = document.getElementById('productCategory');
    if (categorySelect) categorySelect.value = 'wine';
    
    toggleCategoryFields();
    
    // Clear image preview
    const preview = document.getElementById('newProductImagePreview');
    if (preview) preview.innerHTML = '';
    
    const modal = document.getElementById('addProductModal');
    if (modal) modal.style.display = 'flex';
}

// Preview for new product image
function previewNewProductImage() {
    const fileInput = document.getElementById('newProductImage');
    const file = fileInput?.files[0];
    const preview = document.getElementById('newProductImagePreview');
    
    if (file && preview) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.innerHTML = `<img src="${e.target.result}" style="max-width:150px;max-height:150px;border-radius:8px;margin-top:0.5rem;">`;
        };
        reader.readAsDataURL(file);
    }
}

async function addProductFromForm(e) {
    if (e) e.preventDefault();
    console.log('=== addProductFromForm CALLED ===');
    
    if (!currentUser || !currentUser.cellarId) {
        console.error('No currentUser');
        showNotification('მარანი არ არის მინიჭებული', 'error');
        return;
    }
    
    const form = document.getElementById('addProductForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'იტვირთება...';
    submitBtn.disabled = true;
    
    try {
        const category = document.getElementById('productCategory').value;
        console.log('Category:', category);
        
        const product = {
            name: document.getElementById('productName').value.trim(),
            cellarId: currentUser.cellarId,
            category: category,
            price: parseFloat(document.getElementById('productPrice').value),
            year: document.getElementById('productYear').value || null,
            stock: parseInt(document.getElementById('productStock').value) || 0,
            description: document.getElementById('productDescription').value.trim()
        };
        
        if (category === 'wine') {
            product.color = document.getElementById('productColor').value;
            product.sugar = document.getElementById('productSugar').value;
        } else if (category === 'spirit') {
            product.spiritType = document.getElementById('spiritType').value;
            product.alcoholContent = parseFloat(document.getElementById('alcoholContent').value) || 40;
        } else if (category === 'grape') {
            product.grapeProductType = document.getElementById('grapeProductType').value;
        }
        
        console.log('Sending to API:', JSON.stringify(product));
        
        const result = await apiCall('/products', {
            method: 'POST',
            body: JSON.stringify(product)
        });
        
        console.log('API result:', result);
        
        // თუ სურათი არჩეულია, ავტვირთოთ
        const imageFile = document.getElementById('newProductImage')?.files[0];
        if (imageFile && result.id) {
            console.log('Uploading image for new product:', result.id);
            await uploadImageForProduct(result.id, imageFile);
        }
        
        closeCellarModal('addProductModal');
        await loadMyProducts();
        renderMyProducts();
        showNotification('პროდუქტი დაემატა!', 'success');
        
    } catch (error) {
        console.error('Add product error:', error);
        showNotification('შეცდომა: ' + error.message, 'error');
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// Helper function to upload image
async function uploadImageForProduct(productId, file) {
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`/api/products/${productId}/image`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });
        
        if (!response.ok) {
            console.error('Image upload failed');
        } else {
            console.log('Image uploaded successfully');
        }
    } catch (error) {
        console.error('Image upload error:', error);
    }
}

// ========== პროდუქტის რედაქტირება ==========
function editProduct(productId) {
    console.log('editProduct called:', productId);
    const product = myProducts.find(p => p.id === productId);
    if (!product) return;
    
    document.getElementById('editProductId').value = product.id;
    document.getElementById('editProductName').value = product.name;
    document.getElementById('editProductPrice').value = product.price;
    document.getElementById('editProductStock').value = product.stock || 0;
    document.getElementById('editProductDescription').value = product.description || '';
    document.getElementById('editProductModal').style.display = 'flex';
}

async function updateProductFromForm(e) {
    if (e) e.preventDefault();
    
    const form = document.getElementById('editProductForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'შენახვა...';
    submitBtn.disabled = true;
    
    const productId = document.getElementById('editProductId').value;
    
    try {
        await apiCall(`/products/${productId}`, {
            method: 'PUT',
            body: JSON.stringify({
                name: document.getElementById('editProductName').value.trim(),
                price: parseFloat(document.getElementById('editProductPrice').value),
                stock: parseInt(document.getElementById('editProductStock').value) || 0,
                description: document.getElementById('editProductDescription').value.trim()
            })
        });
        
        closeCellarModal('editProductModal');
        await loadMyProducts();
        renderMyProducts();
        showNotification('პროდუქტი განახლდა', 'success');
    } catch (error) {
        showNotification('შეცდომა: ' + error.message, 'error');
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// ========== პროდუქტის წაშლა ==========
async function deleteProduct(productId) {
    console.log('deleteProduct called:', productId);
    if (!confirm('წავშალოთ პროდუქტი?')) return;
    
    try {
        await apiCall(`/products/${productId}`, { method: 'DELETE' });
        await loadMyProducts();
        renderMyProducts();
        showNotification('პროდუქტი წაიშალა', 'success');
    } catch (error) {
        showNotification('შეცდომა: ' + error.message, 'error');
    }
}

// ========== სურათის ატვირთვა ==========
function openImageUploadModal(productId) {
    console.log('openImageUploadModal called for product:', productId);
    document.getElementById('uploadProductId').value = productId;
    
    const form = document.getElementById('imageUploadForm');
    if (form) form.reset();
    
    document.getElementById('imagePreview').innerHTML = '';
    document.getElementById('imageUploadModal').style.display = 'flex';
}

function previewImage() {
    const fileInput = document.getElementById('productImage');
    const file = fileInput?.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('imagePreview').innerHTML = `<img src="${e.target.result}" style="max-width:200px;border-radius:8px;">`;
        };
        reader.readAsDataURL(file);
    }
}

async function uploadProductImage(e) {
    if (e) e.preventDefault();
    console.log('uploadProductImage called');
    
    const productId = document.getElementById('uploadProductId').value;
    const fileInput = document.getElementById('productImage');
    const file = fileInput?.files[0];
    
    if (!file || !productId) {
        showNotification('აირჩიეთ სურათი', 'warning');
        return;
    }
    
    const form = document.getElementById('imageUploadForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'იტვირთება...';
    submitBtn.disabled = true;
    
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`/api/products/${productId}/image`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || 'ატვირთვა ვერ მოხერხდა');
        }
        
        closeCellarModal('imageUploadModal');
        await loadMyProducts();
        renderMyProducts();
        showNotification('სურათი აიტვირთა', 'success');
    } catch (error) {
        console.error('Upload error:', error);
        showNotification('შეცდომა: ' + error.message, 'error');
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// ========== მოდალების მართვა ==========
function closeCellarModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = 'none';
}

// ESC კლავიშით დახურვა
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
    }
});

// Modal background-ზე დაჭერით დახურვა
document.addEventListener('click', e => {
    if (e.target.classList.contains('modal')) {
        e.target.style.display = 'none';
    }
});

console.log('cellar-admin.js fully loaded');
