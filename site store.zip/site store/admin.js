// ========== ადმინის პანელი ==========
let adminSellers = [];
let adminCellars = [];
let allOrders = [];
let filteredOrders = [];
let stats = null;
let paymentStats = null;
let filteredPayments = [];

// ინიციალიზაცია
async function initAdminPanel() {
    // JWT auth შემოწმება
    const isAuth = await checkAuthOnLoad('admin');
    if (!isAuth) return;
    
    await Promise.all([
        loadSellers(),
        loadOrders(),
        loadStats(),
        loadPaymentStats()
    ]);
    renderSellers();
    renderOrders();
    renderStats();
    renderPayments();
}

// ========== ტაბების მართვა ==========
function switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(`${tabName}Tab`).classList.add('active');
    
    if (tabName === 'stats') loadStats().then(renderStats);
    if (tabName === 'payments') loadPaymentStats().then(renderPayments);
}

// ========== მარნები/გამყიდველები ==========
async function loadSellers() {
    try {
        const [usersData, cellarsData] = await Promise.all([
            apiCall('/users'),
            apiCall('/cellars?all=true')  // ადმინი ხედავს ყველა მარანს
        ]);
        adminSellers = usersData.filter(u => u.role === 'cellar_admin');
        adminCellars = cellarsData;
    } catch (error) {
        console.error('მონაცემების ჩატვირთვის შეცდომა:', error);
    }
}

function renderSellers() {
    const tbody = document.getElementById('sellersTableBody');
    if (!tbody) return;
    
    if (adminCellars.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-state">მარნები არ არის დამატებული</td></tr>';
        document.getElementById('totalCellars').textContent = '0';
        return;
    }
    
    document.getElementById('totalCellars').textContent = adminCellars.length;
    
    tbody.innerHTML = adminCellars.map(cellar => {
        const admin = adminSellers.find(s => s.cellarId === cellar.id);
        const isHidden = cellar.hidden;
        const rowClass = isHidden ? 'style="opacity: 0.5; background: #f5f5f5;"' : '';
        const hideIcon = isHidden ? '👁️' : '🙈';
        const hideTitle = isHidden ? 'გამოჩენა' : 'დამალვა';
        
        return `
            <tr ${rowClass}>
                <td>
                    <strong>${escapeHtml(cellar.name)}</strong>
                    ${isHidden ? '<span class="status-badge status-cancelled" style="margin-left:0.5rem;font-size:0.7rem">დამალული</span>' : ''}
                </td>
                <td class="hide-mobile">${admin ? escapeHtml(admin.email) : '-'}</td>
                <td class="hide-mobile">${escapeHtml(cellar.location) || '-'}</td>
                <td>${formatDate(cellar.createdAt)}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn-icon" onclick="openEditCellarModal(${cellar.id})" title="რედაქტირება">✏️</button>
                        ${admin ? `<button class="btn-icon" onclick="openChangePasswordModal(${admin.id}, '${escapeHtml(admin.username)}')" title="პაროლის შეცვლა">🔑</button>` : ''}
                        <button class="btn-icon" onclick="toggleCellarVisibility(${cellar.id})" title="${hideTitle}">${hideIcon}</button>
                        <button class="btn-icon btn-danger" onclick="deleteSeller(${cellar.id})" title="წაშლა">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// ========== შეკვეთები ==========
async function loadOrders() {
    try {
        allOrders = await apiCall('/orders');
        filteredOrders = [...allOrders];
        updateOrdersCount();
    } catch (error) {
        console.error('შეკვეთების ჩატვირთვის შეცდომა:', error);
        allOrders = [];
        filteredOrders = [];
    }
}

function updateOrdersCount() {
    const badge = document.getElementById('ordersCount');
    if (badge) {
        const pendingCount = allOrders.filter(o => o.status === 'pending').length;
        badge.textContent = pendingCount;
        badge.style.display = pendingCount > 0 ? 'inline-flex' : 'none';
    }
}

function filterOrders(status) {
    if (status === 'all') {
        filteredOrders = [...allOrders];
    } else {
        filteredOrders = allOrders.filter(o => o.status === status);
    }
    renderOrders();
}

function renderOrders() {
    const tbody = document.getElementById('ordersTableBody');
    if (!tbody) return;
    
    if (filteredOrders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">შეკვეთები არ არის</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredOrders.map(order => {
        const cellarNames = [...new Set(order.items.map(i => i.cellarName))].join(', ');
        const isPaid = order.paymentStatus === 'paid';
        return `
            <tr class="order-row ${order.status}" onclick="showOrderDetail('${order.id}')">
                <td><code>#${order.id}</code></td>
                <td>
                    <div class="customer-info">
                        <strong>${escapeHtml(order.customer.name)}</strong>
                        <small>${escapeHtml(order.customer.phone)}</small>
                    </div>
                </td>
                <td class="hide-mobile"><small>${escapeHtml(truncate(cellarNames, 30))}</small></td>
                <td><strong>${order.totalAmount.toFixed(2)}₾</strong></td>
                <td>
                    <span class="payment-badge ${isPaid ? 'payment-paid' : 'payment-pending'}" 
                          onclick="event.stopPropagation(); togglePayment('${order.id}', ${isPaid})"
                          title="დააჭირე გადახდის სტატუსის შესაცვლელად">
                        ${isPaid ? '✅ გადახდილი' : '⏳ მოლოდინში'}
                    </span>
                </td>
                <td><span class="status-badge status-${order.status}">${getStatusName(order.status)}</span></td>
                <td class="hide-mobile">${formatDate(order.createdAt)}</td>
            </tr>
        `;
    }).join('');
}

function showOrderDetail(orderId) {
    const order = allOrders.find(o => o.id === orderId);
    if (!order) return;
    
    const content = document.getElementById('orderDetailContent');
    content.innerHTML = `
        <div class="order-detail">
            <div class="order-section">
                <h3>👤 მომხმარებელი</h3>
                <p><strong>სახელი:</strong> ${escapeHtml(order.customer.name)}</p>
                <p><strong>ტელეფონი:</strong> <a href="tel:${order.customer.phone}">${order.customer.phone}</a></p>
                ${order.customer.email ? `<p><strong>ელ.ფოსტა:</strong> ${order.customer.email}</p>` : ''}
                ${order.customer.address ? `<p><strong>მისამართი:</strong> ${order.customer.address}</p>` : ''}
                ${order.customer.comment ? `<p><strong>კომენტარი:</strong> ${order.customer.comment}</p>` : ''}
            </div>
            
            <div class="order-section">
                <h3>📦 პროდუქტები</h3>
                <div class="order-items">
                    ${order.items.map(item => `
                        <div class="order-item">
                            <span>${escapeHtml(item.name)} × ${item.quantity} <small style="color:var(--text-muted)">(${item.cellarName})</small></span>
                            <span>${(item.price * item.quantity).toFixed(2)}₾</span>
                        </div>
                    `).join('')}
                </div>
                <div class="order-total">
                    <strong>სულ: ${order.totalAmount.toFixed(2)}₾</strong>
                </div>
            </div>
            
            <div class="order-section">
                <h3>📋 სტატუსი</h3>
                <select class="status-select" onchange="updateOrderStatus('${order.id}', this.value)">
                    <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>მოლოდინში</option>
                    <option value="confirmed" ${order.status === 'confirmed' ? 'selected' : ''}>დადასტურებული</option>
                    <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>გაგზავნილი</option>
                    <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>მიწოდებული</option>
                    <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>გაუქმებული</option>
                </select>
            </div>
            
            <p class="order-date">შეკვეთის თარიღი: ${new Date(order.createdAt).toLocaleString('ka-GE')}</p>
        </div>
    `;
    
    document.getElementById('orderDetailModal').style.display = 'flex';
}

async function updateOrderStatus(orderId, status) {
    try {
        await apiCall(`/orders/${orderId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status })
        });
        
        const order = allOrders.find(o => o.id === orderId);
        if (order) order.status = status;
        
        updateOrdersCount();
        renderOrders();
        showNotification('სტატუსი განახლდა', 'success');
    } catch (error) {
        showNotification('შეცდომა', 'error');
    }
}

// გადახდის სტატუსის შეცვლა
async function togglePayment(orderId, isPaid) {
    const newStatus = isPaid ? 'pending' : 'paid';
    const confirmMsg = isPaid 
        ? 'გსურთ გადახდის გაუქმება?' 
        : 'დადასტურდეს რომ თანხა გადახდილია?';
    
    if (!confirm(confirmMsg)) return;
    
    try {
        await apiCall(`/orders/${orderId}/payment`, {
            method: 'PUT',
            body: JSON.stringify({ paymentStatus: newStatus })
        });
        
        const order = allOrders.find(o => o.id === orderId);
        if (order) order.paymentStatus = newStatus;
        
        renderOrders();
        showNotification(newStatus === 'paid' ? '✅ გადახდა დადასტურდა' : 'გადახდა გაუქმდა', 'success');
    } catch (error) {
        showNotification('შეცდომა', 'error');
    }
}


// ========== სტატისტიკა ==========
async function loadStats() {
    try {
        stats = await apiCall('/stats/orders');
    } catch (error) {
        console.error('სტატისტიკის ჩატვირთვის შეცდომა:', error);
        stats = { totalOrders: 0, totalRevenue: 0, paidRevenue: 0, cellarStats: [] };
    }
}

function renderStars(rating) {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            stars.push('<span class="star filled">★</span>');
        } else {
            stars.push('<span class="star">☆</span>');
        }
    }
    return `<span class="star-rating">${stars.join('')}</span>`;
}

function getRankBadge(index) {
    const rank = index + 1;
    if (rank === 1) return `<span class="rank-badge rank-1">🥇</span>`;
    if (rank === 2) return `<span class="rank-badge rank-2">🥈</span>`;
    if (rank === 3) return `<span class="rank-badge rank-3">🥉</span>`;
    return `<span class="rank-badge rank-default">${rank}</span>`;
}

function renderStats() {
    if (!stats) return;
    
    document.getElementById('totalOrdersCount').textContent = stats.totalOrders;
    document.getElementById('totalRevenue').textContent = stats.totalRevenue.toFixed(2) + '₾';
    
    // გადახდილი თანხა
    const paidRevenueEl = document.getElementById('paidRevenueStats');
    if (paidRevenueEl) {
        paidRevenueEl.textContent = (stats.paidRevenue || 0).toFixed(2) + '₾';
    }
    
    const tbody = document.getElementById('statsTableBody');
    if (!tbody) return;
    
    if (stats.cellarStats.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">მონაცემები არ არის</td></tr>';
        return;
    }
    
    tbody.innerHTML = stats.cellarStats.map((stat, index) => `
        <tr>
            <td>${getRankBadge(index)}</td>
            <td>
                <strong>${escapeHtml(stat.cellarName)}</strong>
                ${stat.totalOrders === 0 ? '<small style="color: var(--text-muted); display: block;">შეკვეთები არ აქვს</small>' : ''}
            </td>
            <td>${renderStars(stat.rating)}</td>
            <td>
                <strong>${stat.totalOrders}</strong>
                <small style="color: var(--text-muted);">შეკვ.</small>
            </td>
            <td class="hide-mobile">
                <span style="color: #22C55E;">${stat.paidOrders || 0}</span>
                <small style="color: var(--text-muted);">/ ${stat.totalOrders}</small>
            </td>
            <td>
                <strong style="color: var(--primary)">${stat.totalRevenue.toFixed(2)}₾</strong>
                ${stat.paidRevenue !== stat.totalRevenue ? `<small style="color: #22C55E; display: block;">(${(stat.paidRevenue || 0).toFixed(2)}₾ გადახდილი)</small>` : ''}
            </td>
        </tr>
    `).join('');
}

// ========== მარნის დამატება ==========
function openAddSellerModal() {
    document.getElementById('addSellerForm')?.reset();
    document.getElementById('addSellerModal').style.display = 'flex';
}

async function addSellerFromForm(event) {
    event.preventDefault();
    
    const submitBtn = event.target.querySelector('button[type="submit"]');
    submitBtn.textContent = 'იტვირთება...';
    submitBtn.disabled = true;
    
    const cellarName = document.getElementById('newCellarName').value.trim();
    const location = document.getElementById('newCellarLocation').value.trim();
    const description = document.getElementById('newCellarDescription').value.trim();
    const identificationCode = document.getElementById('newCellarIdCode')?.value.trim() || '';
    const iban = document.getElementById('newCellarIban').value.trim();
    const bankName = document.getElementById('newCellarBank').value;
    const accountHolder = document.getElementById('newCellarAccountHolder').value.trim();
    const username = document.getElementById('newSellerUsername').value.trim();
    const email = document.getElementById('newSellerEmail').value.trim();
    const password = document.getElementById('newSellerPassword').value;
    const passwordConfirm = document.getElementById('newSellerPasswordConfirm').value;
    
    // ვალიდაცია
    if (identificationCode && !/^\d{9}$|^\d{11}$/.test(identificationCode)) {
        showNotification('საიდენტიფიკაციო კოდი უნდა იყოს 9 ან 11 ციფრი', 'error');
        submitBtn.textContent = 'დამატება';
        submitBtn.disabled = false;
        return;
    }
    
    if (password !== passwordConfirm) {
        showNotification('პაროლები არ ემთხვევა', 'error');
        submitBtn.textContent = 'დამატება';
        submitBtn.disabled = false;
        return;
    }
    
    if (password.length < 6) {
        showNotification('პაროლი უნდა იყოს მინიმუმ 6 სიმბოლო', 'error');
        submitBtn.textContent = 'დამატება';
        submitBtn.disabled = false;
        return;
    }
    
    try {
        // მარნის შექმნა
        const newCellar = await apiCall('/cellars', {
            method: 'POST',
            body: JSON.stringify({ name: cellarName, location, description, identificationCode, iban, bankName, accountHolder })
        });
        
        // მომხმარებლის შექმნა
        await apiCall('/users', {
            method: 'POST',
            body: JSON.stringify({
                username, email, password,
                role: 'cellar_admin',
                cellarId: newCellar.id
            })
        });
        
        await loadSellers();
        renderSellers();
        closeModal('addSellerModal');
        event.target.reset();
        showNotification('მარანი წარმატებით დაემატა', 'success');
    } catch (error) {
        showNotification(error.message || 'შეცდომა', 'error');
    } finally {
        submitBtn.textContent = 'დამატება';
        submitBtn.disabled = false;
    }
}

async function deleteSeller(cellarId) {
    const cellar = adminCellars.find(c => c.id === cellarId);
    if (!cellar) return;
    
    if (!confirm(`წავშალოთ "${cellar.name}"?\n\nყურადღება: წაიშლება მარანი, მისი ადმინისტრატორი და ყველა პროდუქტი!`)) {
        return;
    }
    
    try {
        await apiCall(`/cellars/${cellarId}`, { method: 'DELETE' });
        await loadSellers();
        renderSellers();
        showNotification('მარანი წაიშალა', 'success');
    } catch (error) {
        showNotification(error.message || 'შეცდომა', 'error');
    }
}

// მარნის დამალვა/გამოჩენა
async function toggleCellarVisibility(cellarId) {
    const cellar = adminCellars.find(c => c.id === cellarId);
    if (!cellar) return;
    
    const action = cellar.hidden ? 'გამოჩენა' : 'დამალვა';
    
    try {
        await apiCall(`/cellars/${cellarId}/visibility`, { method: 'PUT' });
        await loadSellers();
        renderSellers();
        showNotification(`მარანი ${cellar.hidden ? 'გამოჩნდა' : 'დაიმალა'}`, 'success');
    } catch (error) {
        showNotification(error.message || 'შეცდომა', 'error');
    }
}

// ========== დამხმარე ფუნქციები ==========
function getStatusName(status) {
    const statuses = {
        'pending': 'მოლოდინში',
        'confirmed': 'დადასტურებული',
        'shipped': 'გაგზავნილი',
        'delivered': 'მიწოდებული',
        'cancelled': 'გაუქმებული'
    };
    return statuses[status] || status;
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleDateString('ka-GE', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function truncate(str, len) {
    if (!str) return '';
    return str.length > len ? str.substring(0, len) + '...' : str;
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// ========== მარნის რედაქტირება ==========
function openEditCellarModal(cellarId) {
    const cellar = adminCellars.find(c => c.id === cellarId);
    if (!cellar) return;
    
    document.getElementById('editCellarId').value = cellar.id;
    document.getElementById('editCellarName').value = cellar.name || '';
    document.getElementById('editCellarLocation').value = cellar.location || '';
    document.getElementById('editCellarDescription').value = cellar.description || '';
    document.getElementById('editCellarIdCode').value = cellar.identificationCode || '';
    document.getElementById('editCellarIban').value = cellar.iban || '';
    document.getElementById('editCellarBank').value = cellar.bankName || '';
    document.getElementById('editCellarAccountHolder').value = cellar.accountHolder || '';
    document.getElementById('editCellarHidden').value = cellar.hidden ? '1' : '0';
    
    document.getElementById('editCellarModal').style.display = 'flex';
}

async function updateCellarFromForm(e) {
    e.preventDefault();
    
    const id = document.getElementById('editCellarId').value;
    const identificationCode = document.getElementById('editCellarIdCode').value.trim();
    
    // საიდენტიფიკაციო კოდის ვალიდაცია
    if (identificationCode && !/^\d{9}$|^\d{11}$/.test(identificationCode)) {
        showNotification('საიდენტიფიკაციო კოდი უნდა იყოს 9 ან 11 ციფრი', 'error');
        return;
    }
    
    const updates = {
        name: document.getElementById('editCellarName').value.trim(),
        location: document.getElementById('editCellarLocation').value.trim(),
        description: document.getElementById('editCellarDescription').value.trim(),
        identificationCode: identificationCode,
        iban: document.getElementById('editCellarIban').value.trim(),
        bankName: document.getElementById('editCellarBank').value,
        accountHolder: document.getElementById('editCellarAccountHolder').value.trim(),
        hidden: document.getElementById('editCellarHidden').value === '1' ? 1 : 0
    };
    
    if (!updates.name) {
        showNotification('შეიყვანეთ მარნის სახელი', 'error');
        return;
    }
    
    try {
        await apiCall(`/cellars/${id}`, 'PUT', updates);
        closeModal('editCellarModal');
        await loadSellers();
        renderSellers();
        showNotification('მარანი განახლდა', 'success');
    } catch (error) {
        showNotification('შეცდომა: ' + error.message, 'error');
    }
}

// ========== პაროლის შეცვლა ==========
function openChangePasswordModal(userId, username) {
    document.getElementById('changePasswordUserId').value = userId;
    document.getElementById('changePasswordUsername').value = username;
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmNewPassword').value = '';
    document.getElementById('changePasswordModal').style.display = 'flex';
}

async function changePasswordFromForm(e) {
    e.preventDefault();
    
    const userId = document.getElementById('changePasswordUserId').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmNewPassword').value;
    
    if (newPassword.length < 6) {
        showNotification('პაროლი უნდა იყოს მინიმუმ 6 სიმბოლო', 'error');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showNotification('პაროლები არ ემთხვევა', 'error');
        return;
    }
    
    try {
        await apiCall(`/users/${userId}/password`, 'PUT', { password: newPassword });
        closeModal('changePasswordModal');
        showNotification('პაროლი შეიცვალა', 'success');
    } catch (error) {
        showNotification('შეცდომა: ' + error.message, 'error');
    }
}

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
    }
});

document.addEventListener('click', e => {
    if (e.target.classList.contains('modal')) {
        e.target.style.display = 'none';
    }
});

// ინიციალიზაცია
document.addEventListener('DOMContentLoaded', async () => {
    if (document.getElementById('sellersTable')) {
        await initAdminPanel();
        
        // Payment method filter
        const paymentFilter = document.getElementById('paymentMethodFilter');
        if (paymentFilter) {
            paymentFilter.addEventListener('change', function() {
                filterPayments(this.value);
            });
        }
    }
});

// ========== გადახდების მართვა ==========
async function loadPaymentStats() {
    try {
        paymentStats = await apiCall('/stats/payments');
        filteredPayments = [...(paymentStats?.recentPayments || [])];
    } catch (error) {
        console.error('გადახდების სტატისტიკის შეცდომა:', error);
        paymentStats = null;
        filteredPayments = [];
    }
}

function filterPayments(method) {
    if (!paymentStats) return;
    
    if (method === 'all') {
        filteredPayments = [...paymentStats.recentPayments];
    } else {
        filteredPayments = paymentStats.recentPayments.filter(p => p.method === method);
    }
    renderPaymentsTable();
}

function renderPayments() {
    if (!paymentStats) {
        // თუ გადახდების სტატისტიკა ვერ ჩაიტვირთა
        return;
    }
    
    // Summary stats
    const paidCount = document.getElementById('paidCount');
    const pendingCount = document.getElementById('pendingCount');
    const paidAmount = document.getElementById('paidAmount');
    const unipayCount = document.getElementById('unipayCount');
    
    if (paidCount) paidCount.textContent = paymentStats.summary?.totalPaid || 0;
    if (pendingCount) pendingCount.textContent = paymentStats.summary?.totalPending || 0;
    if (paidAmount) paidAmount.textContent = (paymentStats.summary?.paidAmount || 0).toFixed(2) + '₾';
    if (unipayCount) unipayCount.textContent = paymentStats.unipay?.paid || 0;
    
    // Render table
    renderPaymentsTable();
    
    // Render UniPay config
    renderUnipayConfig();
}

function renderPaymentsTable() {
    const tbody = document.getElementById('paymentsTableBody');
    if (!tbody) return;
    
    if (filteredPayments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">გადახდები არ არის</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredPayments.map(payment => `
        <tr>
            <td><code>#${payment.orderId}</code></td>
            <td>${escapeHtml(payment.customerName)}</td>
            <td><strong style="color: #22C55E;">${payment.amount.toFixed(2)}₾</strong></td>
            <td>
                <span class="method-badge ${payment.method === 'UniPay' ? 'method-unipay' : 'method-manual'}">
                    ${payment.method === 'UniPay' ? '💳 UniPay' : '✋ ხელით'}
                </span>
            </td>
            <td>${formatDateTime(payment.paidAt)}</td>
            <td>
                <button class="btn-icon" onclick="showOrderDetail('${payment.orderId}')" title="დეტალები">👁️</button>
            </td>
        </tr>
    `).join('');
}

async function renderUnipayConfig() {
    const container = document.getElementById('unipayConfigInfo');
    if (!container) return;
    
    try {
        const config = await apiCall('/unipay/config');
        
        container.innerHTML = `
            <div class="unipay-config-box">
                <div class="config-item">
                    <div class="label">სტატუსი</div>
                    <div class="value ${config.enabled ? 'enabled' : 'disabled'}">
                        ${config.enabled ? '✅ აქტიური' : '❌ გამორთული'}
                    </div>
                </div>
                <div class="config-item">
                    <div class="label">რეჟიმი</div>
                    <div class="value">
                        ${config.mode === 'sandbox' ? '🧪 სატესტო (Sandbox)' : '🚀 პროდაქშენი'}
                    </div>
                </div>
                <div class="config-item">
                    <div class="label">ვალუტა</div>
                    <div class="value">${config.currency}</div>
                </div>
                <div class="config-item">
                    <div class="label">Merchant კონფიგურაცია</div>
                    <div class="value ${config.merchantConfigured ? 'enabled' : 'disabled'}">
                        ${config.merchantConfigured ? '✅ კონფიგურირებული' : '⚠️ საჭიროებს კონფიგურაციას'}
                    </div>
                </div>
            </div>
            ${config.mode === 'sandbox' ? `
                <div style="margin-top: 1rem; padding: 1rem; background: #FEF3C7; border-radius: var(--radius); color: #92400E;">
                    <strong>⚠️ სატესტო რეჟიმი:</strong> გადახდები სიმულირებულია. პროდაქშენზე გადასასვლელად დაამატეთ რეალური credentials .env ფაილში.
                </div>
            ` : ''}
            ${!config.merchantConfigured ? `
                <div style="margin-top: 1rem; padding: 1rem; background: #FEE2E2; border-radius: var(--radius); color: #991B1B;">
                    <strong>⚠️ კონფიგურაცია საჭიროა:</strong>
                    <ol style="margin: 0.5rem 0 0 1rem; font-size: 0.9rem;">
                        <li>დარეგისტრირდი <a href="https://business.unipay.com" target="_blank">business.unipay.com</a>-ზე</li>
                        <li>მიიღე Merchant ID და Secret Key</li>
                        <li>დაამატე .env ფაილში</li>
                    </ol>
                </div>
            ` : ''}
        `;
    } catch (error) {
        container.innerHTML = `
            <div style="color: #EF4444;">
                ❌ UniPay კონფიგურაციის შეცდომა: ${error.message}
            </div>
        `;
    }
}

function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleString('ka-GE', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}
