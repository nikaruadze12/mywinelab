# 🍷 ღვინის მარნების ონლაინ მაღაზია

ქართული ღვინოების ონლაინ მაღაზია, რომელიც საშუალებას აძლევს პატარა მარნებს გაყიდონ თავიანთი პროდუქცია.

## 🚀 გაშვება

```bash
# დამოკიდებულებების ინსტალაცია
npm install

# სერვერის გაშვება
npm start

# Development რეჟიმი (auto-reload)
npm run dev
```

სერვერი გაეშვება: **http://localhost:3000**

## 👥 მომხმარებლის როლები

### ადმინისტრატორი (admin)
- **მომხმარებელი:** `admin`
- **პაროლი:** `admin123`
- გამყიდველების (მარნების) დამატება/წაშლა
- პანელი: `/admin.html`

### მარნის ადმინისტრატორი (cellar_admin)
- პროდუქტების დამატება/რედაქტირება/წაშლა
- სურათების ატვირთვა
- პანელი: `/cellar-admin.html`

## 📁 პროექტის სტრუქტურა

```
site store/
├── data/                    # მონაცემთა საქაღალდე
│   ├── cellars/             # მარნების საქაღალდეები
│   │   └── cellar_X/        # თითოეული მარნის საქაღალდე
│   │       ├── images/      # პროდუქტების სურათები
│   │       ├── products/    # პროდუქტების JSON
│   │       └── info/        # მარნის ინფორმაცია
│   ├── users.json           # მომხმარებლები
│   ├── cellars.json         # მარნები
│   └── products.json        # პროდუქტები
├── server.js                # Express სერვერი
├── api.js                   # Frontend API helper
├── auth.js                  # ავტორიზაციის სისტემა
├── script.js                # მთავარი გვერდის სკრიპტი
├── admin.js                 # ადმინის პანელის სკრიპტი
├── cellar-admin.js          # მარნის ადმინის სკრიპტი
├── styles.css               # სტილები
├── index.html               # მთავარი გვერდი
├── login.html               # ავტორიზაცია
├── admin.html               # ადმინის პანელი
└── cellar-admin.html        # მარნის პანელი
```

## 🔧 API Endpoints

### მომხმარებლები
- `GET /api/users` - ყველა მომხმარებელი
- `GET /api/users/:id` - მომხმარებელი ID-ით
- `POST /api/users` - მომხმარებლის შექმნა
- `DELETE /api/users/:id` - მომხმარებლის წაშლა
- `POST /api/login` - ავტორიზაცია

### მარნები
- `GET /api/cellars` - ყველა მარანი
- `POST /api/cellars` - მარნის შექმნა
- `DELETE /api/cellars/:id` - მარნის წაშლა

### პროდუქტები
- `GET /api/products` - ყველა პროდუქტი
- `GET /api/products/cellar/:cellarId` - მარნის პროდუქტები
- `GET /api/products/search?q=...` - ძიება
- `POST /api/products` - პროდუქტის შექმნა
- `PUT /api/products/:id` - პროდუქტის განახლება
- `DELETE /api/products/:id` - პროდუქტის წაშლა
- `POST /api/products/:id/image` - სურათის ატვირთვა

## 🔒 უსაფრთხოება

- ✅ პაროლების SHA256 ჰეშირება
- ✅ Input validation და sanitization
- ✅ Rate limiting (100 req/min)
- ✅ File type და size validation
- ✅ XSS protection
- ✅ CORS კონფიგურაცია

## 🍇 ღვინის კლასიფიკაცია

### ფერი (color)
- `white` - თეთრი
- `amber` - ქარვისფერი
- `rose` - ვარდისფერი
- `red` - წითელი

### შაქარი (sugar)
- `dry` - მშრალი
- `semi-dry` - ნახევრად მშრალი
- `semi-sweet` - ნახევრად ტკბილი
- `sweet` - ტკბილი

## 📝 ვერსია

**v2.0.0** - 2024

### ცვლილებები v2.0-ში:
- პაროლების ჰეშირება
- Rate limiting
- Input validation
- გაუმჯობესებული error handling
- Loading states UI-ში
- კოდის რეფაქტორინგი და დუბლიკატების მოშორება
- სურათების წაშლა პროდუქტთან ერთად
- cellar_undefined ბაგის გასწორება
