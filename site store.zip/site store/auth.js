// ========== JWT ავტორიზაციის სისტემა ==========

let accessToken = null;
let tokenRefreshTimer = null;

// Token-ის მიღება
function getAccessToken() {
    if (accessToken) return accessToken;
    return localStorage.getItem('accessToken');
}

// Token-ის შენახვა
function setAccessToken(token) {
    accessToken = token;
    if (token) {
        localStorage.setItem('accessToken', token);
    } else {
        localStorage.removeItem('accessToken');
    }
}

// მომხმარებლის შემოწმება
function isLoggedIn() {
    return localStorage.getItem('currentUser') !== null && getAccessToken() !== null;
}

// მიმდინარე მომხმარებლის მიღება
function getCurrentUser() {
    try {
        const userStr = localStorage.getItem('currentUser');
        return userStr ? JSON.parse(userStr) : null;
    } catch {
        localStorage.removeItem('currentUser');
        return null;
    }
}

// Token refresh setup
function setupTokenRefresh(expiresIn) {
    if (tokenRefreshTimer) {
        clearTimeout(tokenRefreshTimer);
    }
    
    // Refresh 1 minute before expiry
    const refreshTime = (expiresIn - 60) * 1000;
    if (refreshTime > 0) {
        tokenRefreshTimer = setTimeout(refreshAccessToken, refreshTime);
    }
}

// Token განახლება
async function refreshAccessToken() {
    try {
        const response = await fetch('/api/refresh-token', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (!response.ok) {
            throw new Error('Token refresh failed');
        }
        
        const data = await response.json();
        setAccessToken(data.accessToken);
        setupTokenRefresh(data.expiresIn);
        console.log('✅ Token განახლდა');
        return data.accessToken;
    } catch (error) {
        console.error('Token refresh შეცდომა:', error);
        logout();
        return null;
    }
}

// Auth-ით API call
async function authApiCall(endpoint, options = {}) {
    const token = getAccessToken();
    
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    const response = await fetch(`/api${endpoint}`, {
        ...options,
        headers,
        credentials: 'include'
    });
    
    // Token expired - try refresh
    if (response.status === 401) {
        const data = await response.json();
        if (data.code === 'TOKEN_EXPIRED') {
            const newToken = await refreshAccessToken();
            if (newToken) {
                // Retry with new token
                headers['Authorization'] = `Bearer ${newToken}`;
                const retryResponse = await fetch(`/api${endpoint}`, {
                    ...options,
                    headers,
                    credentials: 'include'
                });
                if (!retryResponse.ok) {
                    const error = await retryResponse.json();
                    throw new Error(error.error || 'მოთხოვნა ვერ შესრულდა');
                }
                return retryResponse.json();
            }
        }
        // Auth failed - logout
        logout();
        throw new Error(data.error || 'ავტორიზაცია საჭიროა');
    }
    
    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'მოთხოვნა ვერ შესრულდა');
    }
    
    return response.json();
}

// მომხმარებლების მიღება API-დან
async function getAllUsers() {
    try {
        return await authApiCall('/users');
    } catch (error) {
        console.error('მომხმარებლების ჩატვირთვის შეცდომა:', error);
        return [];
    }
}

// პროდუქტების მიღება
async function getProducts() {
    try {
        return await apiCall('/products');
    } catch (error) {
        console.error('პროდუქტების ჩატვირთვის შეცდომა:', error);
        return [];
    }
}

// მარნების მიღება
async function getCellars() {
    try {
        return await apiCall('/cellars');
    } catch (error) {
        console.error('მარნების ჩატვირთვის შეცდომა:', error);
        return [];
    }
}


// ავტორიზაცია
async function handleLogin(event) {
    event.preventDefault();
    console.log('Login started...');
    
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'იტვირთება...';
    submitBtn.disabled = true;
    
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    
    console.log('Username:', username);
    
    if (!username || !password) {
        showNotification('გთხოვთ შეავსოთ ყველა ველი', 'error');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        return;
    }
    
    try {
        console.log('Sending login request...');
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ username, password })
        });
        
        console.log('Response status:', response.status);
        const data = await response.json();
        console.log('Response data:', data);
        
        if (!response.ok) {
            throw new Error(data.error || 'არასწორი მონაცემები');
        }
        
        // Store user and token
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        setAccessToken(data.accessToken);
        setupTokenRefresh(data.expiresIn);
        
        console.log('Login successful, redirecting...');
        showNotification('წარმატებით შეხვედით!', 'success');
        
        setTimeout(() => {
            if (data.user.role === 'admin') {
                window.location.href = 'admin.html';
            } else if (data.user.role === 'cellar_admin') {
                window.location.href = 'cellar-admin.html';
            } else {
                window.location.href = 'index.html';
            }
        }, 500);
    } catch (error) {
        console.error('Login error:', error);
        showNotification(error.message || 'არასწორი მონაცემები', 'error');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// გასვლა
async function logout() {
    try {
        await fetch('/api/logout', {
            method: 'POST',
            credentials: 'include'
        });
    } catch (e) {}
    
    // Clear local storage
    localStorage.removeItem('currentUser');
    setAccessToken(null);
    sessionStorage.clear();
    
    if (tokenRefreshTimer) {
        clearTimeout(tokenRefreshTimer);
        tokenRefreshTimer = null;
    }
    
    window.history.replaceState(null, '', 'login.html');
    window.location.replace('login.html');
}

// Auth სტატუსის შემოწმება
async function verifyAuth() {
    const token = getAccessToken();
    if (!token) return false;
    
    try {
        const response = await fetch('/api/auth/verify', {
            headers: { 'Authorization': `Bearer ${token}` },
            credentials: 'include'
        });
        
        if (!response.ok) {
            if (response.status === 401) {
                // Try refresh
                const newToken = await refreshAccessToken();
                return !!newToken;
            }
            return false;
        }
        
        const data = await response.json();
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        return true;
    } catch {
        return false;
    }
}

// Page load-ზე auth შემოწმება (admin pages-ისთვის)
async function checkAuthOnLoad(requiredRole = null) {
    const user = getCurrentUser();
    const token = getAccessToken();
    
    if (!user || !token) {
        window.location.replace('login.html');
        return false;
    }
    
    if (requiredRole && user.role !== requiredRole && user.role !== 'admin') {
        showNotification('არასაკმარისი უფლებები', 'error');
        logout();
        return false;
    }
    
    // Verify token is still valid
    const isValid = await verifyAuth();
    if (!isValid) {
        logout();
        return false;
    }
    
    return true;
}

// ტიპის სახელის მიღება ქართულად
function getTypeName(product) {
    const colors = {
        'white': 'თეთრი',
        'amber': 'ქარვისფერი',
        'rose': 'ვარდისფერი',
        'red': 'წითელი'
    };
    
    const sugars = {
        'dry': 'მშრალი',
        'semi-dry': 'ნახევრად მშრალი',
        'semi-sweet': 'ნახევრად ტკბილი',
        'sweet': 'ტკბილი'
    };
    
    if (typeof product === 'object') {
        const colorName = colors[product.color] || '';
        const sugarName = sugars[product.sugar] || '';
        return `${colorName} ${sugarName}`.trim() || product.type || '';
    }
    
    return colors[product] || sugars[product] || product || '';
}


// ========== მობილური მენიუ ==========
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu) {
        navMenu.classList.toggle('active');
    }
}

// ========== Auth Setup (ნავიგაციისთვის) ==========
function setupAuth() {
    const user = getCurrentUser();
    if (user) {
        const loginBtn = document.getElementById('loginBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        const navUserName = document.getElementById('navUserName');
        const adminBtn = document.getElementById('adminPanelBtn');
        const cellarBtn = document.getElementById('cellarPanelBtn');
        
        if (loginBtn) loginBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'inline';
        if (navUserName) {
            navUserName.style.display = 'inline';
            navUserName.textContent = user.username;
        }
        if (user.role === 'admin' && adminBtn) {
            adminBtn.style.display = 'inline';
        } else if (user.role === 'cellar_admin' && cellarBtn) {
            cellarBtn.style.display = 'inline';
        }
    }
}

// ========== მოდალის დახურვა ==========
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        modal.style.display = 'none';
    }
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        modal.style.display = 'flex';
    }
}
