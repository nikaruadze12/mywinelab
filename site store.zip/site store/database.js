/**
 * SQLite Database Module for WineLab
 * Replaces JSON file storage with SQLite
 */

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'winelab.db');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize database
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

// ============ SCHEMA CREATION ============
function initializeDatabase() {
    db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            salt TEXT NOT NULL,
            role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'cellar_admin', 'user')),
            cellarId INTEGER,
            createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
            updatedAt TEXT DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS cellars (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            location TEXT,
            description TEXT,
            established TEXT,
            identificationCode TEXT,
            iban TEXT,
            bankName TEXT,
            accountHolder TEXT,
            hidden INTEGER DEFAULT 0,
            createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
            updatedAt TEXT DEFAULT CURRENT_TIMESTAMP
        )
    `);
    
    // მიგრაცია - identificationCode ველის დამატება თუ არ არსებობს
    try {
        db.exec(`ALTER TABLE cellars ADD COLUMN identificationCode TEXT`);
        console.log('✅ identificationCode ველი დაემატა cellars ცხრილს');
    } catch (e) {
        // ველი უკვე არსებობს
    }

    db.exec(`
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            cellarId INTEGER NOT NULL,
            cellarName TEXT,
            category TEXT DEFAULT 'wine',
            type TEXT,
            color TEXT,
            sugar TEXT,
            spiritType TEXT,
            alcoholContent REAL,
            grapeProductType TEXT,
            price REAL NOT NULL,
            year INTEGER,
            stock INTEGER DEFAULT 0,
            lowStockAlertSent INTEGER DEFAULT 0,
            description TEXT,
            image TEXT,
            createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
            updatedAt TEXT DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY,
            customerName TEXT NOT NULL,
            customerPhone TEXT NOT NULL,
            customerEmail TEXT,
            customerAddress TEXT,
            customerComment TEXT,
            totalAmount REAL NOT NULL,
            status TEXT DEFAULT 'pending',
            paymentStatus TEXT DEFAULT 'pending',
            paidAt TEXT,
            createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
            updatedAt TEXT DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            orderId TEXT NOT NULL,
            productId INTEGER NOT NULL,
            productName TEXT NOT NULL,
            price REAL NOT NULL,
            quantity INTEGER NOT NULL,
            cellarId INTEGER NOT NULL,
            cellarName TEXT
        )
    `);

    db.exec(`
        CREATE INDEX IF NOT EXISTS idx_products_cellarId ON products(cellarId);
        CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
        CREATE INDEX IF NOT EXISTS idx_order_items_orderId ON order_items(orderId);
        CREATE INDEX IF NOT EXISTS idx_users_cellarId ON users(cellarId);
    `);

    console.log('✅ SQLite ბაზა ინიციალიზებულია');
}

// Initialize on module load
initializeDatabase();

// ============ USERS ============
const users = {
    getAll: () => db.prepare('SELECT * FROM users').all(),
    getById: (id) => db.prepare('SELECT * FROM users WHERE id = ?').get(id),
    getByUsername: (username) => db.prepare('SELECT * FROM users WHERE LOWER(username) = LOWER(?)').get(username),
    getByEmail: (email) => db.prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?)').get(email),
    getByCellarId: (cellarId) => db.prepare('SELECT * FROM users WHERE cellarId = ?').get(cellarId),
    
    create: (data) => {
        const stmt = db.prepare(`
            INSERT INTO users (username, email, password, salt, role, cellarId, createdAt)
            VALUES (@username, @email, @password, @salt, @role, @cellarId, @createdAt)
        `);
        const result = stmt.run(data);
        return { id: result.lastInsertRowid, ...data };
    },
    
    update: (id, data) => {
        const stmt = db.prepare(`
            UPDATE users SET username = @username, email = @email, password = @password, updatedAt = datetime('now')
            WHERE id = @id
        `);
        return stmt.run({ id, ...data });
    },
    
    updatePassword: (id, password, salt) => {
        return db.prepare(`
            UPDATE users SET password = ?, salt = ?, updatedAt = datetime('now') WHERE id = ?
        `).run(password, salt, id);
    },
    
    delete: (id) => db.prepare('DELETE FROM users WHERE id = ?').run(id),
    deleteByCellarId: (cellarId) => db.prepare('DELETE FROM users WHERE cellarId = ?').run(cellarId)
};

// ============ CELLARS ============
const cellars = {
    getAll: () => db.prepare('SELECT * FROM cellars').all(),
    getVisible: () => db.prepare('SELECT * FROM cellars WHERE hidden = 0').all(),
    getById: (id) => db.prepare('SELECT * FROM cellars WHERE id = ?').get(id),
    
    // საჯარო მონაცემები (identificationCode-ის გარეშე) - cellar_admin და მომხმარებლებისთვის
    getByIdPublic: (id) => {
        const cellar = db.prepare('SELECT * FROM cellars WHERE id = ?').get(id);
        if (cellar) {
            const { identificationCode, ...publicData } = cellar;
            return publicData;
        }
        return null;
    },
    
    // საჯარო სია (identificationCode-ის გარეშე)
    getAllPublic: () => {
        return db.prepare('SELECT id, name, location, description, established, iban, bankName, accountHolder, hidden, createdAt, updatedAt FROM cellars').all();
    },
    
    create: (data) => {
        const stmt = db.prepare(`
            INSERT INTO cellars (name, location, description, established, identificationCode, iban, bankName, accountHolder, createdAt)
            VALUES (@name, @location, @description, @established, @identificationCode, @iban, @bankName, @accountHolder, @createdAt)
        `);
        const result = stmt.run({
            ...data,
            identificationCode: data.identificationCode || null
        });
        return { id: result.lastInsertRowid, ...data };
    },
    
    update: (id, data) => {
        const fields = [];
        const values = { id };
        
        if (data.name !== undefined) { fields.push('name = @name'); values.name = data.name; }
        if (data.location !== undefined) { fields.push('location = @location'); values.location = data.location; }
        if (data.description !== undefined) { fields.push('description = @description'); values.description = data.description; }
        if (data.established !== undefined) { fields.push('established = @established'); values.established = data.established; }
        if (data.identificationCode !== undefined) { fields.push('identificationCode = @identificationCode'); values.identificationCode = data.identificationCode; }
        if (data.iban !== undefined) { fields.push('iban = @iban'); values.iban = data.iban; }
        if (data.bankName !== undefined) { fields.push('bankName = @bankName'); values.bankName = data.bankName; }
        if (data.accountHolder !== undefined) { fields.push('accountHolder = @accountHolder'); values.accountHolder = data.accountHolder; }
        
        if (fields.length === 0) return null;
        
        fields.push("updatedAt = datetime('now')");
        const sql = `UPDATE cellars SET ${fields.join(', ')} WHERE id = @id`;
        return db.prepare(sql).run(values);
    },
    
    toggleVisibility: (id) => {
        return db.prepare("UPDATE cellars SET hidden = NOT hidden, updatedAt = datetime('now') WHERE id = ?").run(id);
    },
    
    delete: (id) => db.prepare('DELETE FROM cellars WHERE id = ?').run(id)
};

// ============ PRODUCTS ============
const products = {
    getAll: () => db.prepare('SELECT * FROM products').all(),
    getById: (id) => db.prepare('SELECT * FROM products WHERE id = ?').get(id),
    getByCellarId: (cellarId) => db.prepare('SELECT * FROM products WHERE cellarId = ?').all(cellarId),
    
    create: (data) => {
        const stmt = db.prepare(`
            INSERT INTO products (name, cellarId, cellarName, category, type, color, sugar,
                spiritType, alcoholContent, grapeProductType, price, year, stock, description, image, createdAt)
            VALUES (@name, @cellarId, @cellarName, @category, @type, @color, @sugar,
                @spiritType, @alcoholContent, @grapeProductType, @price, @year, @stock, @description, @image, @createdAt)
        `);
        const result = stmt.run(data);
        return { id: result.lastInsertRowid, ...data };
    },
    
    update: (id, data) => {
        // Flexible update - მხოლოდ გადაცემული ველების განახლება
        const fields = [];
        const values = { id };
        
        if (data.name !== undefined) { fields.push('name = @name'); values.name = data.name; }
        if (data.type !== undefined) { fields.push('type = @type'); values.type = data.type; }
        if (data.color !== undefined) { fields.push('color = @color'); values.color = data.color; }
        if (data.sugar !== undefined) { fields.push('sugar = @sugar'); values.sugar = data.sugar; }
        if (data.spiritType !== undefined) { fields.push('spiritType = @spiritType'); values.spiritType = data.spiritType; }
        if (data.alcoholContent !== undefined) { fields.push('alcoholContent = @alcoholContent'); values.alcoholContent = data.alcoholContent; }
        if (data.grapeProductType !== undefined) { fields.push('grapeProductType = @grapeProductType'); values.grapeProductType = data.grapeProductType; }
        if (data.price !== undefined) { fields.push('price = @price'); values.price = data.price; }
        if (data.year !== undefined) { fields.push('year = @year'); values.year = data.year; }
        if (data.stock !== undefined) { fields.push('stock = @stock'); values.stock = data.stock; }
        if (data.description !== undefined) { fields.push('description = @description'); values.description = data.description; }
        
        if (fields.length === 0) return null;
        
        fields.push("updatedAt = datetime('now')");
        const sql = `UPDATE products SET ${fields.join(', ')} WHERE id = @id`;
        return db.prepare(sql).run(values);
    },
    
    updateImage: (id, image) => {
        return db.prepare("UPDATE products SET image = ?, updatedAt = datetime('now') WHERE id = ?").run(image, id);
    },
    
    updateStock: (id, quantity) => {
        return db.prepare("UPDATE products SET stock = stock - ?, updatedAt = datetime('now') WHERE id = ?").run(quantity, id);
    },
    
    // მარაგის შევსებისას alert-ის reset
    setStock: (id, newStock) => {
        // თუ მარაგი 15-ზე მეტი გახდა, alert reset
        const resetAlert = newStock > 15 ? 0 : null;
        if (resetAlert !== null) {
            return db.prepare("UPDATE products SET stock = ?, lowStockAlertSent = 0, updatedAt = datetime('now') WHERE id = ?").run(newStock, id);
        }
        return db.prepare("UPDATE products SET stock = ?, updatedAt = datetime('now') WHERE id = ?").run(newStock, id);
    },
    
    // Alert გაგზავნის მარკერი
    markLowStockAlertSent: (id) => {
        return db.prepare("UPDATE products SET lowStockAlertSent = 1, updatedAt = datetime('now') WHERE id = ?").run(id);
    },
    
    // შევამოწმოთ საჭიროა თუ არა alert გაგზავნა
    needsLowStockAlert: (id) => {
        const product = db.prepare("SELECT stock, lowStockAlertSent FROM products WHERE id = ?").get(id);
        return product && product.stock <= 15 && product.lowStockAlertSent === 0;
    },
    
    delete: (id) => db.prepare('DELETE FROM products WHERE id = ?').run(id),
    deleteByCellarId: (cellarId) => db.prepare('DELETE FROM products WHERE cellarId = ?').run(cellarId)
};

// ============ ORDERS ============
const orders = {
    getAll: () => db.prepare('SELECT * FROM orders ORDER BY createdAt DESC').all(),
    getById: (id) => db.prepare('SELECT * FROM orders WHERE id = ?').get(id),
    
    create: (data) => {
        const stmt = db.prepare(`
            INSERT INTO orders (id, customerName, customerPhone, customerEmail, customerAddress,
                customerComment, totalAmount, status, paymentStatus, createdAt)
            VALUES (@id, @customerName, @customerPhone, @customerEmail, @customerAddress,
                @customerComment, @totalAmount, @status, @paymentStatus, @createdAt)
        `);
        return stmt.run(data);
    },
    
    updateStatus: (id, status) => {
        return db.prepare("UPDATE orders SET status = ?, updatedAt = datetime('now') WHERE id = ?").run(status, id);
    },
    
    updatePaymentStatus: (id, paymentStatus) => {
        const paidAt = paymentStatus === 'paid' ? new Date().toISOString() : null;
        return db.prepare(`
            UPDATE orders SET paymentStatus = ?, paidAt = COALESCE(?, paidAt), updatedAt = datetime('now') WHERE id = ?
        `).run(paymentStatus, paidAt, id);
    },
    
    // UniPay Payment ID შენახვა
    updatePaymentId: (orderId, unipayPaymentId) => {
        return db.prepare(`
            UPDATE orders SET unipayPaymentId = ?, updatedAt = datetime('now') WHERE id = ?
        `).run(unipayPaymentId, orderId);
    },
    
    // შეკვეთის მოძებნა orderId-ით (MIRPXXXX ფორმატი)
    getByOrderId: (orderId) => {
        return db.prepare("SELECT * FROM orders WHERE id = ?").get(orderId);
    }
};

// ============ ORDER ITEMS ============
const orderItems = {
    getByOrderId: (orderId) => db.prepare('SELECT * FROM order_items WHERE orderId = ?').all(orderId),
    getByCellarId: (cellarId) => db.prepare('SELECT * FROM order_items WHERE cellarId = ?').all(cellarId),
    
    create: (data) => {
        const stmt = db.prepare(`
            INSERT INTO order_items (orderId, productId, productName, price, quantity, cellarId, cellarName)
            VALUES (@orderId, @productId, @productName, @price, @quantity, @cellarId, @cellarName)
        `);
        return stmt.run(data);
    }
};

// ============ HELPER FUNCTIONS ============

function getOrderWithItems(orderId) {
    const order = orders.getById(orderId);
    if (!order) return null;
    
    const items = orderItems.getByOrderId(orderId);
    return {
        id: order.id,
        customer: {
            name: order.customerName,
            phone: order.customerPhone,
            email: order.customerEmail,
            address: order.customerAddress,
            comment: order.customerComment
        },
        items,
        totalAmount: order.totalAmount,
        status: order.status,
        paymentStatus: order.paymentStatus,
        paidAt: order.paidAt,
        unipayPaymentId: order.unipayPaymentId,
        createdAt: order.createdAt,
        updatedAt: order.updatedAt
    };
}

function getAllOrdersWithItems() {
    const allOrders = orders.getAll();
    return allOrders.map(order => ({
        id: order.id,
        customer: {
            name: order.customerName,
            phone: order.customerPhone,
            email: order.customerEmail,
            address: order.customerAddress,
            comment: order.customerComment
        },
        items: orderItems.getByOrderId(order.id),
        totalAmount: order.totalAmount,
        status: order.status,
        paymentStatus: order.paymentStatus,
        paidAt: order.paidAt,
        unipayPaymentId: order.unipayPaymentId,
        createdAt: order.createdAt,
        updatedAt: order.updatedAt
    }));
}

function getCellarOrders(cellarId) {
    const items = orderItems.getByCellarId(cellarId);
    const orderIds = [...new Set(items.map(i => i.orderId))];
    
    return orderIds.map(orderId => {
        const order = orders.getById(orderId);
        if (!order) return null;
        
        const cellarItems = items.filter(i => i.orderId === orderId);
        const cellarTotal = cellarItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
        
        return {
            id: order.id,
            customer: {
                name: order.customerName,
                phone: order.customerPhone,
                email: order.customerEmail,
                address: order.customerAddress,
                comment: order.customerComment
            },
            items: cellarItems,
            cellarTotal,
            totalAmount: order.totalAmount,
            status: order.status,
            paymentStatus: order.paymentStatus,
            createdAt: order.createdAt,
            updatedAt: order.updatedAt
        };
    }).filter(o => o !== null).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

const createOrderWithItems = db.transaction((orderData, itemsData) => {
    orders.create(orderData);
    
    for (const item of itemsData) {
        orderItems.create(item);
        if (item.quantity > 0) {
            products.updateStock(item.productId, item.quantity);
        }
    }
});

const deleteCellarWithData = db.transaction((cellarId) => {
    users.deleteByCellarId(cellarId);
    products.deleteByCellarId(cellarId);
    cellars.delete(cellarId);
});

// ============ EXPORTS ============
module.exports = {
    db,
    initializeDatabase,
    users,
    cellars,
    products,
    orders,
    orderItems,
    getOrderWithItems,
    getAllOrdersWithItems,
    getCellarOrders,
    createOrderWithItems,
    deleteCellarWithData
};
