// UniPay Configuration for WineLab
// რეგისტრაცია: https://business.unipay.com
// დოკუმენტაცია: https://docs.unipay.com

module.exports = {
    // სატესტო რეჟიმი (sandbox)
    sandbox: {
        baseUrl: 'https://checkout-api.unipay.com/v1',
        // სატესტო credentials - ჩაანაცვლე რეალურით რეგისტრაციის შემდეგ
        merchantId: process.env.UNIPAY_SANDBOX_MERCHANT_ID || 'SANDBOX_MERCHANT',
        secretKey: process.env.UNIPAY_SANDBOX_SECRET_KEY || 'SANDBOX_SECRET'
    },
    
    // პროდაქშენი - .env-დან იკითხება
    production: {
        baseUrl: 'https://checkout-api.unipay.com/v1',
        merchantId: process.env.UNIPAY_MERCHANT_ID || '',
        secretKey: process.env.UNIPAY_SECRET_KEY || ''
    },
    
    // რომელი mode გამოვიყენოთ: 'sandbox' ან 'production'
    mode: process.env.UNIPAY_MODE || 'sandbox',
    
    // Callback URLs
    getCallbackUrls: (baseUrl) => ({
        successUrl: `${baseUrl}/payment-success.html`,
        failUrl: `${baseUrl}/payment-fail.html`,
        callbackUrl: `${baseUrl}/api/unipay/callback`
    }),
    
    // მხარდაჭერილი ვალუტა - საქართველოში მხოლოდ GEL
    currency: 'GEL',
    
    // გადახდის მეთოდები
    paymentMethods: ['card', 'wallet', 'googlepay', 'applepay'],
    
    // API Endpoints
    endpoints: {
        createOrder: '/checkout/orders',
        orderStatus: '/checkout/orders/{orderId}',
        refund: '/checkout/orders/{orderId}/refund'
    },
    
    // Webhook signature verification
    verifySignature: (payload, signature, secretKey) => {
        const crypto = require('crypto');
        const expectedSignature = crypto
            .createHmac('sha256', secretKey)
            .update(JSON.stringify(payload))
            .digest('hex');
        return signature === expectedSignature;
    }
};
